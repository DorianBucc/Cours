export class Monnaie {
    private _nom! : string;
    private _valeur! : number;
    private _valeurEnEuros! : number;

    constructor(nom : string, valeur : number, valeurEnEuros : number) {
        this.nom = nom;
        this.valeur = valeur;
        this.valeurEnEuros = valeurEnEuros;
    }

    public get nom() : string {
        return this._nom;
    }
    public set nom(nom : string) {
        nom = nom.trim();
        if (nom.length >= 3) {
            this._nom = nom;
        } else {
            throw new Error("Le nom doit faire au moins 3 caractères");
        }
    }

    public get valeur() : number {
        return this._valeur;
    }
    public set valeur(valeur : number) {
        this._valeur = valeur;
    }

    public get valeurEnEuros() : number {
        return this._valeurEnEuros;
    }
    public set valeurEnEuros(valeurEnEuros : number) {
        this._valeurEnEuros = valeurEnEuros;
    }
    public toString() : string {
        return `${this.nom} : ${this.valeur} (${this.valeurEnEuros} euros)`;
    }

}
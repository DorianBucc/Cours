import { Adherent } from "./Adherent.ts";
import { Document } from "./Document.ts";

export class Emprunt {
  private _dateEmprunt: Date;
  private _dateRetour: Date;
  private _emprunteur: Adherent;
  private _documents: Array<Document>;

  public constructor(
    dateEmprunt: Date,
    dateRetour: Date,
    emprunteur: Adherent,
    documents: Array<Document>,
  ) {
    this._dateEmprunt = dateEmprunt;
    this._dateRetour = dateRetour;
    this._emprunteur = emprunteur;
    this._documents = documents;
  }

  public get dateEmprunt(): Date {
    return this._dateEmprunt;
  }

  public get dateRetour(): Date {
    return this._dateRetour;
  }

  public get emprunteur(): Adherent {
    return this._emprunteur;
  }

  public get documents(): Array<Document> {
    return this._documents;
  }

  public toString(): string {
    return `Emprunt du ${this._dateEmprunt.toLocaleDateString()} au ${this._dateRetour.toLocaleDateString()} par ${this._emprunteur.toString()} : \n\t${
      this._documents.toString().replaceAll("\t", "\t\t").replaceAll(
        " ,",
        "\n\t",
      )
    }`;
  }
}

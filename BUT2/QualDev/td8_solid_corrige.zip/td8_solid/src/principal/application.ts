import { litChaine, litEntier, litReel } from "../utils/Saisie.ts";
import { Sportif } from "../modele/Sportif.ts";
import { Compte } from "../modele/tiers/Compte.ts";
import { ObjetConnecte } from "../modele/tiers/ObjetConnecte.ts";
import { Activite } from "../modele/activites/Activite.ts";
import { FournisseurDonnees } from "../modele/tiers/FournisseurDonnees.ts";
import { Cyclisme } from "../modele/activites/Cyclisme.ts";
import { CourseAPied } from "../modele/activites/CourseAPied.ts";
import { Musculation } from "../modele/activites/Musculation.ts";


function creeMembres() : Array<Sportif> {
    const membre1 = new Sportif(1, "Jean", "Dupont", new Date(1980, 1, 1), "M", 180, 70);
    const membre2 = new Sportif(2, "Marie", "Durand", new Date(1985, 2, 2), "F", 170, 50);
    const membre3 = new Sportif(3, "Pierre", "Martin", new Date(1990, 3, 3), "M", 190, 90);

    const membres = [membre1, membre2, membre3];

    return membres;
}

function ajouteComptes(membres : Array<Sportif>) : void {
    
    const objJD = new ObjetConnecte(124710, "Montre");
    const objMD = new ObjetConnecte(124711, "Tacx");
    const objPM = new ObjetConnecte(325710, "Montre");
    membres[0].ajouterFournisseurDonnees(objJD);
    membres[1].ajouterFournisseurDonnees(objMD);
    membres[2].ajouterFournisseurDonnees(objPM);
    
    const cptJD = new Compte(124712, "Polar");
    const cptMD = new Compte(124713, "Garmin");    
    membres[0].ajouterFournisseurDonnees(cptJD);
    membres[1].ajouterFournisseurDonnees(cptMD);
    
    const strJD = new Compte(124714, "Strava");
    membres[0].ajouterFournisseurDonnees(strJD);
    objJD.ajouterCompteLie(strJD);
    cptJD.ajouterCompteLie(strJD);
    
    const strMD = new Compte(124715, "Strava");
    membres[1].ajouterFournisseurDonnees(strMD);
    objMD.ajouterCompteLie(strMD);
    cptMD.ajouterCompteLie(strMD);

    const strPM = new Compte(124716, "Strava");
    membres[2].ajouterFournisseurDonnees(strPM);
    objPM.ajouterCompteLie(strPM);

    const decJD = new Compte(124717, "Decathlon");
    membres[0].ajouterFournisseurDonnees(decJD);
    objJD.ajouterCompteLie(decJD);
    cptJD.ajouterCompteLie(decJD);
}

function afficheMembres(membres : Array<Sportif>) : void {

    console.log("Liste des membres du club :");
    for (const membre of membres) {    
        console.log(membre.toString());
        console.log("Liste des comptes du membre :");
        for (const compte of membre.listeComptes) {
            console.log("\t" + compte.toString());

            console.log("\tListe des comptes connectés :");
            for (const cpt of compte.listeComptesLies) {
                console.log("\t\t" + cpt.toString());
            }
        }
    }
}


function afficheActivites(membre : Sportif) : void {

    console.log("Liste des activités de : " + membre.toString());
    for (const source of membre.listeComptes) {    
        console.log(source.toString());
        console.log("Liste des activités de ce compte :");
        for (const activite of source.listeActivites) {
            console.log("\t" + activite.toString());
        }
    }
}

function saisieDebutActivite() : [Date, number, number] {

    const dateActivite = new Date(Date.now());
    const duree = litReel("Durée de l'activité : ");
    const bpmMoyen = litEntier("BPM moyen : ");

    return [dateActivite, duree, bpmMoyen];
}

function saisieCyclisme(noActivite : number, fournisseur : FournisseurDonnees) : Activite {

    const [dateActivite, duree, bpmMoyen] = saisieDebutActivite();
    const distance = litEntier("Distance (en m) : ");
    const denivele = litEntier("Dénivelé (en m) : ");
    const ftp = litReel("FTP : ");

    return new Cyclisme(noActivite, dateActivite, duree, bpmMoyen, distance, denivele, ftp, fournisseur);
}

function saisieCourseAPied(noActivite : number, fournisseur : FournisseurDonnees) : Activite {

    const [dateActivite, duree, bpmMoyen] = saisieDebutActivite();
    const distance = litEntier("Distance (en m) : ");
    const cadence = litEntier("Cadence : ");

    return new CourseAPied(noActivite, dateActivite, duree, bpmMoyen, distance, cadence, fournisseur);
}

function saisieMusculation(noActivite : number, fournisseur : FournisseurDonnees) : Activite {

    const [dateActivite, duree, bpmMoyen] = saisieDebutActivite();
    const titre = litChaine("Titre : ");
    const membre = litChaine("Membre(s) du corps concerné(s): ");

    return new Musculation(noActivite, dateActivite, duree, bpmMoyen, titre, membre, fournisseur);
}

function menuInteractif(membres : Array<Sportif>) : void {

    let noActivite = 5436;

    let saisie : number;
    do {
        do {            
            saisie = litEntier(`Quel membre ? (1-${membres.length}, 0 pour quitter) : `);
        } while (saisie < 0 || saisie > membres.length);
        if (saisie===0) {
            break;
        }    
        const noMembre=saisie-1;
        console.log("Liste des comptes du membre :");
        let cpt=0;
        for (const compte of membres[noMembre].listeComptes) {
            console.log(`\t${cpt} ${compte.toString()}`);
            cpt++;
        }

        let noCpt:number;
        do {
            noCpt = litEntier("Quel compte ? ");
        } while (noCpt < 0 || noCpt >= cpt);

        console.log("Type d'activité ?");
        let noType : number;
        do {
            noType = litEntier("1. Cyclisme\n2. Course à pied\n3. Musculation\nVotre choix : ");
        } while (noType < 1 || noType > 3);
        switch (noType) {
            case 1:
                membres[noMembre].listeComptes[noCpt].ajouterActivite(saisieCyclisme(noActivite, membres[noMembre].listeComptes[noCpt]));
                break;
            case 2:
                membres[noMembre].listeComptes[noCpt].ajouterActivite(saisieCourseAPied(noActivite, membres[noMembre].listeComptes[noCpt]));
                break;
            case 3:
                membres[noMembre].listeComptes[noCpt].ajouterActivite(saisieMusculation(noActivite, membres[noMembre].listeComptes[noCpt]));
                break;
        }

        noActivite++;
        afficheActivites(membres[noMembre]);
    } while (saisie !== 0);
}


const membres = creeMembres();
ajouteComptes(membres);
afficheMembres(membres);

menuInteractif(membres);



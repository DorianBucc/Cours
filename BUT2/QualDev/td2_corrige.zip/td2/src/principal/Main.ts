import { Auteur } from "../modele/Auteur.ts";
import { CD } from "../modele/CD.ts";
import { Livre } from "../modele/Livre.ts";
import { Role } from "../modele/Role.ts";
import { Adherent } from "../modele/Adherent.ts";
import { Bibliotheque } from "../modele/Bibliotheque.ts";
import { Emprunt } from "../modele/Emprunt.ts";

const auteursVD = new Map<Auteur, Array<Role | null>>();
auteursVD.set(new Auteur("Ohkubo", "Akiyo"), [new Role("auteur principal")]);
auteursVD.set(new Auteur("Gerriet", "Julie"), [
  new Role("traducteur"),
  new Role("dessinateur"),
]);

const l = new Livre("Vlad Draculea, 4", auteursVD, "Soleil", "manga");

const auteursL2 = new Map<Auteur, Array<Role | null>>();
auteursL2.set(new Auteur("Uderzo", "Albert"), [null]);
const l2 = new Livre(
  "Le grand fossé",
  auteursL2,
  "Dargaud",
  "Astérix le Gaulois",
);

const auteursT = new Map<Auteur, Array<Role | null>>();
auteursT.set(new Auteur("Townsend", "Devin"), [
  new Role("auteur"),
  new Role("compositeur"),
]);
const cd = new CD("Terria", auteursT, "Inside Out", [
  "Rock",
  "Hard progressif",
]);

console.log(l.toString());
console.log(l2.toString());
console.log(cd.toString());

const ad = new Adherent("123456", "Dupont", "Jean");
const biblio = new Bibliotheque([l, l2, cd], [ad]);
console.log(biblio.toString());

const e = new Emprunt(
  new Date(Date.now()),
  new Date(Date.now() + 3600000 * 240),
  ad,
  [
    l2,
    cd,
  ],
);

console.log("\n");
console.log(e.toString());

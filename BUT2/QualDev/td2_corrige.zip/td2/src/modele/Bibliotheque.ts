import { Adherent } from "./Adherent.ts";
import { Document } from "./Document.ts";

export class Bibliotheque {
  private _documents: Array<Document>;
  private _adherents: Array<Adherent>;

  public constructor(documents: Array<Document>, adherents: Array<Adherent>) {
    this._documents = [];
    for (const unDoc of documents) {
      this.ajouteDocument(unDoc);
    }
    this._adherents = [];
    for (const unAdh of adherents) {
      this.ajouteAdherent(unAdh);
    }
  }

  public get adherents(): Array<Adherent> {
    return this._adherents;
  }

  public ajouteAdherent(a: Adherent): void {
    let doublon = false;
    for (const adh of this._adherents) {
      if (JSON.stringify(adh) === JSON.stringify(a)) {
        doublon = true;
        break;
      }
    }
    if (doublon) {
      throw new Error("Adhérent déjà enregistré, ajout impossible !");
    }
    this._adherents.push(a);
  }

  public supprimeAdherent(a: Adherent): void {
    let idx = -1;
    for (let i = 0; i < this._adherents.length; i++) {
      if (JSON.stringify(this._adherents[i]) === JSON.stringify(a)) {
        idx = i;
        break;
      }
    }
    if (idx === -1) {
      throw new Error("Adhérent inconnu, suppression impossible !");
    }
    this._adherents.splice(idx, 1);
  }

  public get documents(): Array<Document> {
    return this._documents;
  }

  public ajouteDocument(d: Document): void {
    let doublon = false;
    for (const doc of this._documents) {
      if (JSON.stringify(doc) === JSON.stringify(d)) {
        doublon = true;
        break;
      }
    }
    if (doublon) {
      throw new Error("Document déjà enregistré, ajout impossible !");
    }
    this._documents.push(d);
  }

  public supprimeDocument(d: Document): void {
    let idx = -1;
    for (let i = 0; i < this._documents.length; i++) {
      if (JSON.stringify(this._documents[i]) === JSON.stringify(d)) {
        idx = i;
        break;
      }
    }
    if (idx === -1) {
      throw new Error("Document inconnu, suppression impossible !");
    }
    this._documents.splice(idx, 1);
  }

  public toString(): string {
    return "Bibliothèque : \nDocuments : \n" +
      this._documents.toString().replaceAll(" ,", "\n") +
      "\nAdhérents : \n" +
      this._adherents.toString();
  }
}

export enum Description {
  GROUPE = "groupe",
  AUTEUR_PRINCIPAL = "auteur principal",
  AUTEUR = "auteur",
  COMPOSITEUR = "compositeur",
  TRADUCTEUR = "traducteur",
  DESSINATEUR = "dessinateur",
  SCENARISTE = "scénariste",
}

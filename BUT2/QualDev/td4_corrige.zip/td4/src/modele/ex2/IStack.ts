export interface IStack<T> {

    push(element : T): void;
    pop() : T;
    peek() : T;
    isEmpty() : boolean;
    size() : number;
}
function genereChaineVoyelles(taille: number): string {
  const voyelles = ["a", "e", "i", "o", "u", "y"];
  const longueur = voyelles.length;
  // Ajout des majuscules
  for (let v = 0; v < longueur; v++) {
    voyelles.push(voyelles[v].toUpperCase());
  }

  let resultat = "";

  for (let i = 0; i < taille; i++) {
    const indice = Math.floor(voyelles.length * Math.random());
    resultat += voyelles[indice];
  }

  return resultat;
}

console.log(genereChaineVoyelles(5));

import { Personne } from "./Personne.ts";

export class Auteur extends Personne {
  public constructor(nom: string, prenom = "") {
    super(nom, prenom);
  }

  public set prenom(prenom: string) {
    this._prenom = prenom.trim();
  }

  /***
   * Redéfinition de la méthode get prenom() de la classe Personne
   * car on a redéfini le setter de prenom
   * sinon a.prenom renvoie undefined
   * Ceci est une particularité TypeScript
   */
  public get prenom(): string {
    return this._prenom;
  }

  public toString(): string {
    if (this._prenom === "") {
      return this._nom;
    }
    return super.toString();
  }
}

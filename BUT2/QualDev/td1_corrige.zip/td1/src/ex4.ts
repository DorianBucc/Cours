/*
Code Unicode de 'A' : 65
Code Unicode de 'z' : 123
Entre 'Z' et 'a' il y a des caractères non alphabétiques (exemple : [, ], etc.)
*/
function genereChaine(): string {
  let resultat: string;
  let compteur = 0;

  do {
    resultat = "";
    for (let i = 0; i < 5; i++) {
      const car = String.fromCharCode(65 + (123 - 65) * Math.random());
      resultat += car;
    }
    compteur++;
    console.log("Tentative " + compteur + " : " + resultat);
  } while (resultat !== resultat.toUpperCase());
  console.log("Nb itérations : " + compteur);

  return resultat;
}

genereChaine();

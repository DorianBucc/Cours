-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 15 mars 2023 à 09:23
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `school`
--

-- --------------------------------------------------------

--
-- Structure de la table `adherent`
--

DROP TABLE IF EXISTS `adherent`;
CREATE TABLE IF NOT EXISTS `adherent` (
  `no_adh` int NOT NULL,
  `nom_adh` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ad_adh` int NOT NULL,
  `tel_adh` int NOT NULL,
  `iban` int NOT NULL,
  `actif` int NOT NULL,
  `date_adh` date NOT NULL,
  `date_fin` date NOT NULL,
  PRIMARY KEY (`no_adh`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `apport`
--

DROP TABLE IF EXISTS `apport`;
CREATE TABLE IF NOT EXISTS `apport` (
  `no_contrat` int NOT NULL,
  `code_site` int NOT NULL,
  `date_sortie` date NOT NULL,
  `qte_ap` int NOT NULL,
  PRIMARY KEY (`no_contrat`,`code_site`,`date_sortie`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `bourse`
--

DROP TABLE IF EXISTS `bourse`;
CREATE TABLE IF NOT EXISTS `bourse` (
  `no_bourse` int NOT NULL,
  `nom_bourse` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `lieu_bourse` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`no_bourse`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `cereale`
--

DROP TABLE IF EXISTS `cereale`;
CREATE TABLE IF NOT EXISTS `cereale` (
  `code_cereale` int NOT NULL,
  `nom_cereale` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date_crea` date NOT NULL,
  `retiree` int NOT NULL,
  `date_retrait` date NOT NULL,
  PRIMARY KEY (`code_cereale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `num_cl` int NOT NULL,
  `nom_cl` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ad_cl` int NOT NULL,
  `type_activ` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`num_cl`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `commission`
--

DROP TABLE IF EXISTS `commission`;
CREATE TABLE IF NOT EXISTS `commission` (
  `code_cereale` int NOT NULL,
  `annee` int NOT NULL,
  `tx_site` int NOT NULL,
  `tx_st_adh` int NOT NULL,
  `prix_achat` int NOT NULL,
  PRIMARY KEY (`code_cereale`,`annee`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `contrat`
--

DROP TABLE IF EXISTS `contrat`;
CREATE TABLE IF NOT EXISTS `contrat` (
  `no_contrat` int NOT NULL,
  `date_contrat` date NOT NULL,
  `qte_prev` int NOT NULL,
  `qte_restante` int NOT NULL,
  `liv_immed` int NOT NULL,
  `date_liv_prev` date NOT NULL,
  `date_paiement` date NOT NULL,
  `no_adh` int NOT NULL,
  `code_cereale` int NOT NULL,
  PRIMARY KEY (`no_contrat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

DROP TABLE IF EXISTS `cours`;
CREATE TABLE IF NOT EXISTS `cours` (
  `code_cereale` int NOT NULL,
  `no_bourse` int NOT NULL,
  `date_cours` date NOT NULL,
  `tarif_tonne` int NOT NULL,
  PRIMARY KEY (`code_cereale`,`no_bourse`,`date_cours`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

DROP TABLE IF EXISTS `facture`;
CREATE TABLE IF NOT EXISTS `facture` (
  `no_fact` int NOT NULL,
  `date_fact` date NOT NULL,
  `date_encais` date NOT NULL,
  `num_marche` int NOT NULL,
  PRIMARY KEY (`no_fact`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `marche`
--

DROP TABLE IF EXISTS `marche`;
CREATE TABLE IF NOT EXISTS `marche` (
  `num_marche` int NOT NULL,
  `date_marche` date NOT NULL,
  `qte_cdee` int NOT NULL,
  `prix_vente` int NOT NULL,
  `date_liv_prev` date NOT NULL,
  `type_liv` int NOT NULL,
  `num_cl` int NOT NULL,
  `code_cereale` int NOT NULL,
  PRIMARY KEY (`num_marche`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `pai-contrat`
--

DROP TABLE IF EXISTS `pai-contrat`;
CREATE TABLE IF NOT EXISTS `pai-contrat` (
  `no_paiement` int NOT NULL,
  `date_pai` date NOT NULL,
  `mt` int NOT NULL,
  `no_contrat` int NOT NULL,
  PRIMARY KEY (`no_paiement`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `site`
--

DROP TABLE IF EXISTS `site`;
CREATE TABLE IF NOT EXISTS `site` (
  `code_site` int NOT NULL,
  PRIMARY KEY (`code_site`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `sortie`
--

DROP TABLE IF EXISTS `sortie`;
CREATE TABLE IF NOT EXISTS `sortie` (
  `num_marche` int NOT NULL,
  `code_site` int NOT NULL,
  `date_sortie` date NOT NULL,
  `qte_sortie` int NOT NULL,
  PRIMARY KEY (`num_marche`,`code_site`,`date_sortie`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE IF NOT EXISTS `stock` (
  `code_site` int NOT NULL,
  `code_cereale` int NOT NULL,
  `annee` int NOT NULL,
  `peut_recevoir` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `st_res` int NOT NULL,
  `st_ajust` int NOT NULL,
  PRIMARY KEY (`code_site`,`code_cereale`,`annee`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `stock-adh`
--

DROP TABLE IF EXISTS `stock-adh`;
CREATE TABLE IF NOT EXISTS `stock-adh` (
  `no_adh` int NOT NULL,
  `code_cereale` int NOT NULL,
  `annee` int NOT NULL,
  `peut_stocker` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `st_res` int NOT NULL,
  `st_ajust` int NOT NULL,
  PRIMARY KEY (`no_adh`,`code_cereale`,`annee`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

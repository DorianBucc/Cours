import { FournisseurDonnees } from "../tiers/FournisseurDonnees.ts";
import { Activite } from "./Activite.ts";

export class Cyclisme extends Activite {

    private _distance! : number;
    private _denivele! : number;
    private _ftp! : number;

    public constructor(id : number, dateHeure : Date, duree : number, bpmMoyen : number, distance : number, denivele : number, ftp : number, compte : FournisseurDonnees) {
        super(id, dateHeure, duree, bpmMoyen, compte);
        this.distance = distance;
        this.denivele = denivele;
        this.ftp = ftp;
    }

    public get distance() : number {
        return this._distance;
    }

    public set distance(distance : number) {
        if (distance <= 0) {
            throw new Error("La distance doit être positive");
        }
        this._distance = distance;
    }

    public get denivele() : number {
        return this._denivele;
    }

    public set denivele(denivele : number) {
        if (denivele <= 0) {
            throw new Error("Le dénivelé doit être positif");
        }
        this._denivele = denivele;
    }

    public get ftp() : number {
        return this._ftp;
    }

    public set ftp(ftp : number) {
        if (ftp <= 0) {
            throw new Error("Le FTP doit être positif");
        }
        this._ftp = ftp;
    }

    public get type() : string {
        return "Cyclisme";
    }

    public toString() : string {
        return `${super.toString()} : ${this.distance} km, ${this.denivele} m de dénivelé, ${this.ftp} W`;
    }

}
import { IEqualize } from "./IEqualize.ts";

export class ObjectMap<K extends IEqualize, V> extends Map<K, V> {

    
    public get(key: K): V | undefined {
        for (const [k, v] of this) {
            if (k.equals(key)) {
                return v;
            }
        }
        return undefined;
    }

    public set(key: K, value: V): this {
        for (const [k] of this) {
            if (k.equals(key)) {
                super.set(k, value);
                return this;
            }
        }
        super.set(key, value);
        return this;
    }

    public has(key: K): boolean {
        
        return this.get(key) !== undefined;
    }

} 
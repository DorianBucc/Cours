<!DOCTYPE html>
<head>
  <meta charset="UTF-8" />
  <title>Formulaires - méthode PUT</title>
  <link rel="stylesheet" href="formulaires.css" />
</head>
<body>
  <section>
    <h1>Formulaire de saisie</h1>
    <form action = 'formulaires.php' method = 'post'>
      <fieldset >
      <legend>Saisie des données personnelles</legend>     
        <div class='identite'>
          <label>NOM : </label>
          <input type='text' name='nom' value = '<?= $nom ?>' placeholder='entrez votre nom' required />
          <label>Prénom : </label>
          <input type='text' name='prenom' value = '<?= $prenom ?>' placeholder='entrez votre prénom' required />
          <label>Age : </label>
          <input type='number' name='age' value = '<?= $age?>' placeholder='entrez un entier' required />
          <label>Genre : </label>
          <div>  
              <input type = "radio" name = "sexe" value="F" <?php echo ($genre=='F')?'checked = "checked"': " " ?>/>Féminin
              <input type = "radio" name = "sexe" value="M" <?php echo ($genre=='M')?'checked = "checked"': " " ?>/>Masculin
              <input type = "radio" name = "sexe" value="A"
              <?php
                  if ($genre==='A' || $genre===null)
                    echo 'checked = "checked"';
              ?>
              />Autre
          </div>
        </div>
      </fieldset>

      <fieldset>
        <legend>Compétences dans les langages informatiques </legend>
        <?php     
          foreach ($listeLangages as $unLangage){
            echo "<input type='checkbox' name='langages[$unLangage]' value='$unLangage' ";
            if ($unLangage === "Aucun") {
              if (!isset($langages)) echo ' checked';
              else unset($langages[$unLangage]);
            }
            elseif (isset($langages[$unLangage])) echo ' checked';
   		      echo " /> $unLangage";
          }
        ?>
      </fieldset>

      <fieldset>
        <legend>Langue maternelle</legend>
        <select name = "langue" />
        <?php
          foreach ($langues as $lang){
            echo "<option value='$lang'";
            if ($lang==$langue) {
              echo ' selected';
            }
            echo ">", $lang, "</option>";
          }
        ?>
        </select>
      </fieldset>

      <input type = 'submit' name = 'valider'  value = 'Validez'>

      <!-- le type 'reset' vide le formulaire avant validation ==> pas d'action php  -->    
      <input type = 'reset'  name = 'reset'    value = 'Annulez'>

      <!-- le type 'submit' envoie les données saisies ==> action PHP -->      
      <input type = 'submit' name = 'resetPHP' value = 'Annulez en PHP'>

    </form>
    <?php


    if (!empty($nom)){
      echo "<p>Bonjour $prenom, vous avez $age ans.</p>";
      $typeGenre = ($genre == "F")?"une femme": (($genre == "M")?"un homme":"de sexe inconnu");
      echo "<p>Vous êtes $typeGenre.</p>";
      echo "<p>Vous connaissez les langages suivants : ";
      foreach ($langages as $key => $value) {
        echo $key, ' ';
      }
      echo "<p>Votre langue maternelle est : ". $langue."</p>";
    }
    ?>
  </section>
</body>

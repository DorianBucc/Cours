import { Role } from "./Role.ts";
import { Auteur } from "./Auteur.ts";
import { Utils } from "../utils/Utils.ts";

export abstract class Document {
  protected _titre!: string;
  protected _auteurs!: Map<Auteur, Array<Role | null>>;
  protected _editeur!: string;

  public constructor(
    titre: string,
    auteurs: Map<Auteur, Array<Role | null>>,
    editeur: string,
  ) {
    this.titre = titre;
    this.auteurs = auteurs;
    this.editeur = editeur;
  }

  public set titre(titre: string) {
    titre = titre.trim();
    if (titre.length < 1) {
      throw new Error(
        "Le titre d'un document doit comporter au moins un caractère !",
      );
    }
    this._titre = titre;
  }

  public get titre(): string {
    return this._titre;
  }

  public set auteurs(auteurs: Map<Auteur, Array<Role | null>>) {
    this._auteurs = auteurs;
  }

  public get auteurs(): Map<Auteur, Array<Role | null>> {
    return this._auteurs;
  }

  public set editeur(editeur: string) {
    editeur = editeur.trim();
    if (editeur.length < 2) {
      throw new Error("L'éditeur doit comporter au moins 2 caractère !");
    }
    this._editeur = editeur;
  }

  public get editeur(): string {
    return this._editeur;
  }

  public toString(): string {
    return `${this._titre} (${this.editeur})\n\tAuteurs : ${
      Utils.auteursToString(this._auteurs)
    }`;
  }
}

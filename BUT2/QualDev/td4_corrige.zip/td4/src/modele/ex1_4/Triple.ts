export class Triple<T, U, V> {
  private _first!: T;
  private _second!: U;
  private _third!: V;

  constructor(first: T, second: U, third: V) {
    this.first = first;
    this.second = second;
    this.third = third;
  }

  public get first(): T {
    return this._first;
  }

  public set first(first: T) {
    this._first = first;
  }

  public get second(): U {
    return this._second;
  }

  public set second(second: U) {
    this._second = second;
  }

  public get third(): V {
    return this._third;
  }

  public set third(third: V) {
    this._third = third;
  }

  public toString(): string {
    return this._first + ", " + this._second + ", " + this._third;
  }
}

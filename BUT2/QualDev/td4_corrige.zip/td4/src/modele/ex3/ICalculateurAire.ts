export interface ICalculateurAire {
  getAire(): number;
}

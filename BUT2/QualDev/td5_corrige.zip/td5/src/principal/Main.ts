import { Enseignant } from "../modele/Enseignant.ts";
import { EnseignantV2 } from "../modele/EnseignantV2.ts";
import { Object2StringMap } from "../modele/Object2StringMap.ts";
import { ObjectMap } from "../modele/ObjectMap.ts";

const testVersion1 = () => {
    console.log("Version 1 avec string");

    const tab = new Object2StringMap<Enseignant, number>();

    const e1 = new Enseignant(1, "Dupont", "Jean");
    const e1aussi = new Enseignant(1, "DUPONT", "jean");
    const e1corrige = new Enseignant(1, "Dupond", "Jean");
    const e2 = new Enseignant(3, "Martin", "Marie");
    
    console.log("ajout e1");

    tab.set(e1, 250);
    console.log(tab);
    console.log(tab.get(e1));

    console.log("ajout e2");
    tab.set(e2, 384);
    console.log(tab);
    console.log(tab.get(e2));

    console.log("ajout doublon e1aussi : OK");
    tab.set(e1aussi, 192);
    console.log(tab);
    console.log(tab.get(e1aussi));
    console.log(tab.get(e1));

    console.log("ajout doublon avec nom corrigé : PAS OK !");
    tab.set(e1corrige, 320);
    console.log(tab);
    console.log(tab.get(e1corrige));
    console.log(tab.get(e1));
}   

const testVersion2 = () => {
    console.log("Version 2 avec interface IEqualize");

    const tab = new ObjectMap<EnseignantV2, number>();

    const e1 = new EnseignantV2(1, "Dupont", "Jean");
    const e1aussi = new EnseignantV2(1, "Dupond", "Jean");
    const e1corrige = new EnseignantV2(1, "Dupond", "Jean");
    const e2 = new EnseignantV2(3, "Martin", "Marie");

    console.log("ajout e1");

    tab.set(e1, 250);
    console.log(tab);
    console.log(tab.get(e1));

    console.log("ajout e2");
    tab.set(e2, 384);
    console.log(tab);
    console.log(tab.get(e2));

    console.log("ajout doublon e1aussi : OK");
    tab.set(e1aussi, 192);
    console.log(tab);
    console.log(tab.get(e1aussi));
    console.log(tab.get(e1));

    console.log("ajout doublon avec nom corrigé : OK !");
    tab.set(e1corrige, 320);
    console.log(tab);
    console.log(tab.get(e1corrige));
    console.log(tab.get(e1));
}   

testVersion1();
testVersion2();

import { inverse } from "./utils_ex1.ts";

const tab = ["il", "fait", "beau", "aujourd'hui", "c'est agréable"];

// 1)
tab.forEach(elt=>console.log(elt));
// 2)
tab.forEach((elt, idx) => console.log("case " + idx + " : " + elt));
// 3)
tab.forEach((elt, idx) => tab[idx] = elt.toUpperCase());
tab.forEach(elt=>console.log(elt));
// 4)
tab.forEach((elt, idx) => {
    if (idx < tab.length / 2) {
        const tmp = tab[tab.length - 1 - idx];
        tab[idx] = tmp;
        tab[tab.length - 1 - idx] = elt;
    }
});
tab.forEach(elt=>console.log(elt));

//5)
tab.forEach(inverse);
tab.forEach(elt=>console.log(elt));
import { Athlete } from "../modele/Athlete.ts";

export class FileAthleteDAO {
  public static async chargeAthletes(dossier: string): Promise<Athlete[]> {
    const liste: Athlete[] = [];
    const donnees = await Deno.readTextFile(
      "./src/donnees/" + dossier + "/athletes.txt",
    );

    const lignes = donnees.split("\n");

    for (const ligne of lignes) {
      const infoAthlete = ligne.split(";");
      const athlete = new Athlete(
        infoAthlete[0],
        infoAthlete[1],
        infoAthlete[2],
        Number.parseInt(infoAthlete[3]),
      );
      liste.push(athlete);
    }
    return liste;
  }
}

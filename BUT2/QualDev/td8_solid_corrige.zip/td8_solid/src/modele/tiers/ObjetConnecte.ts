import { FournisseurDonnees } from "./FournisseurDonnees.ts";

export class ObjetConnecte extends FournisseurDonnees {
    
    private _type! : string;

    public constructor(id : number, type : string) {
        super(id);
        this.type = type;
    }

    public get type() : string {
        return this._type;
    }

    public set type(type : string) {
        if (type.length < 2) {
            throw new Error("Le type doit contenir au moins 2 caractères");
        }
        this._type = type;
    }

    public toString() : string {
        return `Objet connecté ${this.type} ${this.id}`;
    }
}
import { IStack } from "./IStack.ts";

export class Stack<T> implements IStack<T> {
  private tableau: Array<T>;

  constructor() {
    this.tableau = [];
  }

  push(element: T): void {
    this.tableau.push(element);
  }

  pop(): T {
    const last = this.peek();
    this.tableau.splice(this.tableau.length - 1);
    return last;
  }

  peek(): T {
    if (this.isEmpty()) {
      throw new Error("Erreur : pile vide !");
    } else {
      return this.tableau[this.tableau.length - 1];
    }
  }

  isEmpty(): boolean {
    return this.tableau.length === 0;
  }

  size(): number {
    return this.tableau.length;
  }
}

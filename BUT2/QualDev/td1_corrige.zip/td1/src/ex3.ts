function crypte(chaine: string): string {
  const lettres = ["A", "B", "E", "G", "I", "O", "S", "Z"];
  const cryptees = ["4", "8", "3", "6", "1", "0", "5", "2"];

  let chCryptee = "";
  for (let c = 0; c < chaine.length; c++) {
    // recherche de la cième lettre de la chaîne dans le tableau
    // des lettres à crypter
    // si on ne trouve pas (idx=-1), on concatène la lettre
    // sinon on concatène sa version cryptée
    const idx = lettres.indexOf(chaine[c].toUpperCase());
    if (idx === -1) {
      chCryptee += chaine[c];
    } else {
      chCryptee += cryptees[idx];
    }
  }

  return chCryptee;
}

console.log(crypte("A L'ASSAUT DE LA GEODE BLEUIE ZEBREE"));
console.log(crypte("A l'assaut de la Geode Bleuie Zebree"));

import { FournisseurDonnees } from "../tiers/FournisseurDonnees.ts";
import { Activite } from "./Activite.ts";

export class Musculation extends Activite {

    private _titre! : string;
    private _membre! : string;

    public constructor(id : number, dateHeure : Date, duree : number, bpmMoyen : number, titre : string, membre : string, compte : FournisseurDonnees) {
        super(id, dateHeure, duree, bpmMoyen, compte);
        this.titre = titre;
        this.membre = membre;
    }

    public get titre() : string {
        return this._titre;
    }

    public set titre(titre : string) {
        this._titre = titre;
    }

    public get membre() : string {
        return this._membre;
    }

    public set membre(membre : string) {
        this._membre = membre;
    }

    public get type() : string {
        return "Musculation";
    }

    public toString() : string {
        return `${super.toString()} : ${this.titre} ${this.membre}`;
    }

}
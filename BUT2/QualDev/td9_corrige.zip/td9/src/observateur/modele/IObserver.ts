import { Observable } from "./Observable.ts";

export interface IObserver {

    notify(o : Observable) : void;
}
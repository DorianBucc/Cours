-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 26 avr. 2023 à 08:37
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bdd`
--

-- --------------------------------------------------------

--
-- Structure de la table `adherent`
--

DROP TABLE IF EXISTS `adherent`;
CREATE TABLE IF NOT EXISTS `adherent` (
  `no_adh` int NOT NULL,
  `nom_adh` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ad_adh` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `tel_adh` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `iban` varchar(20) NOT NULL,
  `actif` tinyint(1) NOT NULL,
  `date_adh` date NOT NULL,
  `date_fin` date NOT NULL,
  PRIMARY KEY (`no_adh`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `adherent`
--

INSERT INTO `adherent` (`no_adh`, `nom_adh`, `ad_adh`, `tel_adh`, `iban`, `actif`, `date_adh`, `date_fin`) VALUES
(1, 'Legrand', '5 rue Principale, 57000', '0601020304', 'FR00001111', 1, '2023-03-01', '0000-00-00'),
(2, 'Darnaud', '5 rue Dupont, 57000', '0601020310', 'FR00002222', 1, '2022-02-07', '0000-00-00'),
(3, 'Haffner', '15 rue Dupont, 57000', '0601020345', 'FR00001122', 0, '2022-04-15', '2023-02-20'),
(4, 'Hoellinger', '15 rue Matignon, 57000', '0601020378', 'FR00001212', 1, '2021-06-17', '0000-00-00'),
(5, 'Albert', '20 rue Dupont, 57000', '0601020312', 'FR00000101', 0, '2022-05-12', '2023-01-09'),
(6, 'Lirnot', '5 rue du Jardin, 88000', '0601020325', 'FR00001010', 1, '2023-01-10', '0000-00-00'),
(7, 'Dupuit', '7 avenue Serpenoise, 57000', '0601020327', 'FR00002936', 1, '2022-01-10', '0000-00-00'),
(8, 'Durand', '13 avenue de Metz, 88000', '0601020338', 'FR00002186', 1, '2022-09-22', '0000-00-00'),
(9, 'Pamel', '3 rue de la Fontaine, 57220', '0601020395', 'FR00008345', 0, '2015-03-21', '2018-02-09'),
(10, 'Laroche', '6 rue du Pot, 57530', '0601020355', 'FR000084569', 1, '2022-11-21', '0000-00-00'),
(11, 'Martin', '10 avenue Victor Hugo, 57000', '0601020301', 'FR00004242', 0, '2022-12-05', '2023-04-18'),
(12, 'Dubois', '25 rue de la Gare, 57000', '0601020366', 'FR00005678', 1, '2023-02-28', '0000-00-00'),
(13, 'Leclerc', '8 rue de la Liberté, 57000', '0601020372', 'FR00009876', 1, '2022-09-10', '0000-00-00'),
(14, 'Garcia', '14 avenue Foch, 57000', '0601020389', 'FR00006543', 0, '2023-01-15', '2023-05-01'),
(15, 'Dupont', '3 rue des Lilas, 88000', '0601020398', 'FR00007777', 1, '2022-07-22', '0000-00-00'),
(16, 'Thomas', '9 avenue des Champs-Élysées, 75008', '0601020316', 'FR00009090', 1, '2023-04-02', '0000-00-00'),
(17, 'Petit', '12 rue Saint-Michel, 57000', '0601020322', 'FR00003333', 0, '2023-03-18', '2023-05-10'),
(18, 'Robert', '21 rue des Fleurs, 88000', '0601020335', 'FR00004444', 1, '2023-02-15', '0000-00-00'),
(19, 'Girard', '6 avenue de Strasbourg, 57000', '0601020349', 'FR00005555', 0, '2023-01-05', '2023-04-25'),
(20, 'Moreau', '18 rue de la Paix, 57000', '0601020357', 'FR00006666', 1, '2023-03-30', '0000-00-00'),
(21, 'Lefebvre', '4 avenue Foch, 88000', '0601020368', 'FR00007777', 1, '2023-04-20', '0000-00-00'),
(22, 'Lambert', '11 rue de la République, 57000', '0601020376', 'FR00008888', 0, '2023-02-12', '2023-05-15'),
(23, 'Fontaine', '7 avenue Victor Hugo, 57000', '0601020385', 'FR00009999', 1, '2023-03-10', '0000-00-00'),
(24, 'Rousseau', '16 rue du Commerce, 88000', '0601020394', 'FR00001234', 1, '2023-02-05', '0000-00-00'),
(25, 'Mercier', '5 avenue de Metz, 57000', '0601020308', 'FR00004567', 0, '2023-01-20', '2023-04-28'),
(26, 'Dupuis', '10 rue de la Gare, 57000', '0601020315', 'FR00005678', 1, '2023-04-05', '0000-00-00'),
(27, 'Lopez', '17 rue du Loup, 88000', '0601020324', 'FR00006789', 1, '2023-03-25', '0000-00-00'),
(28, 'Clement', '5 avenue de Verdun, 57000', '0601020337', 'FR00007890', 0, '2023-02-15', '2023-05-12'),
(29, 'Gonzalez', '13 rue du Temple, 57000', '0601020346', 'FR00008901', 1, '2023-03-15', '0000-00-00'),
(30, 'Bertrand', '6 avenue Carnot, 88000', '0601020354', 'FR00001010', 1, '2023-04-10', '0000-00-00'),
(31, 'Roux', '8 rue des Acacias, 57000', '0601020365', 'FR00001111', 0, '2023-02-10', '2023-05-08'),
(32, 'Vincent', '15 rue Saint-Pierre, 57000', '0601020379', 'FR00002222', 1, '2023-03-05', '0000-00-00'),
(33, 'Fournier', '20 avenue de Gaulle, 57000', '0601020388', 'FR00003333', 0, '2023-01-25', '2023-04-30'),
(34, 'Morel', '12 rue de la Mairie, 88000', '0601020397', 'FR00004444', 1, '2023-04-15', '0000-00-00'),
(35, 'Lemoine', '19 rue Nationale, 57000', '0601020307', 'FR00005555', 0, '2023-03-01', '2023-05-10'),
(36, 'Dubois', '5 avenue Victor Hugo, 57000', '0601020319', 'FR00006666', 1, '2023-04-08', '0000-00-00');

-- --------------------------------------------------------

--
-- Structure de la table `apport`
--

DROP TABLE IF EXISTS `apport`;
CREATE TABLE IF NOT EXISTS `apport` (
  `no_contrat` int NOT NULL,
  `code_site` int NOT NULL,
  `date_ap` date NOT NULL,
  `qte_ap` int NOT NULL,
  PRIMARY KEY (`no_contrat`,`code_site`,`date_ap`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `apport`
--

INSERT INTO `apport` (`no_contrat`, `code_site`, `date_ap`, `qte_ap`) VALUES
(1, 1, '0000-00-00', 0),
(2, 2, '0000-00-00', 0),
(3, 3, '2023-02-20', 1500),
(4, 4, '0000-00-00', 0),
(5, 5, '2023-01-09', 1000),
(6, 1, '2023-10-10', 1000),
(6, 1, '2023-10-13', 4000),
(3, 1, '2022-07-20', 1500),
(4, 4, '2022-07-10', 500),
(4, 5, '2022-07-25', 2500),
(11, 4, '2022-07-13', 1000);

-- --------------------------------------------------------

--
-- Structure de la table `bourse`
--

DROP TABLE IF EXISTS `bourse`;
CREATE TABLE IF NOT EXISTS `bourse` (
  `no_bourse` int NOT NULL,
  `nom_bourse` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `lieu_bourse` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`no_bourse`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `bourse`
--

INSERT INTO `bourse` (`no_bourse`, `nom_bourse`, `lieu_bourse`) VALUES
(1, 'BleBourse', 'France'),
(2, 'MaisBourse', 'France'),
(3, 'AvoineBourse', 'France'),
(4, 'ColzaBourse', 'France'),
(5, 'OrgeBourse', 'France'),
(6, 'SorghoBourse', 'France'),
(7, 'SeigleBourse', 'France'),
(11, 'BleBourse', 'Allemagne'),
(22, 'MaisBourse', 'Allemagne'),
(33, 'AvoineBourse', 'Allemagne'),
(44, 'ColzaBourse', 'Allemagne'),
(45, 'OrgeBourse', 'Allemagne'),
(66, 'SorghoBourse', 'Allemagne'),
(77, 'SeigleBourse', 'Allemagne');

-- --------------------------------------------------------

--
-- Structure de la table `cereale`
--

DROP TABLE IF EXISTS `cereale`;
CREATE TABLE IF NOT EXISTS `cereale` (
  `code_cereale` int NOT NULL,
  `nom_cereale` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date_crea` date NOT NULL,
  `retiree` tinyint(1) NOT NULL,
  `date_retrait` date NOT NULL,
  PRIMARY KEY (`code_cereale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `cereale`
--

INSERT INTO `cereale` (`code_cereale`, `nom_cereale`, `date_crea`, `retiree`, `date_retrait`) VALUES
(1, 'Blé', '2010-03-01', 0, '0000-00-00'),
(2, 'Maïs', '2020-01-25', 1, '2023-03-01'),
(3, 'Avoine', '2019-06-08', 0, '0000-00-00'),
(4, 'Colza', '2020-05-17', 1, '2023-02-20'),
(5, 'Orge', '2015-06-20', 0, '0000-00-00'),
(6, 'Sorgho', '2023-01-15', 0, '0000-00-00'),
(7, 'Seigle', '2013-10-16', 0, '0000-00-00'),
(8, 'Riz', '2022-11-30', 0, '0000-00-00'),
(9, 'Millet', '2023-02-10', 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `num_cl` varchar(100) NOT NULL,
  `nom_cl` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ad_cl` varchar(20) NOT NULL,
  `type_activ` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`num_cl`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`num_cl`, `nom_cl`, `ad_cl`, `type_activ`) VALUES
('1', 'Gallon', '14 rue Clocher, 5750', 'Paysan'),
('2', 'Buchiotty', '19 rue Jardin, 57530', 'Jardinier'),
('3', 'Dagon', '19 rue Dodane, 57645', 'Conducteur de Tracteur'),
('4', 'Lemercier', '20 rue Coupe, 57645', 'Coiffeur'),
('5', 'Justin', 'Sous un pont', 'Chomeur'),
('6', 'Ducret', '56 rue de la Vadroui', 'Meunier'),
('7', 'Larousse', '2 rue de la Charpe', 'Agriculteur'),
('8', 'Leclerc', '14 avenue Charle', 'Traiteur'),
('9', 'Roland', '1 rue de la Chapelle', 'Agriculteur'),
('10', 'Lemarc', '10 rue du Chateau', 'Boulangerie'),
('11', 'Martel', '5 rue des Champs, 57530', 'Agriculteur'),
('12', 'Berger', '8 avenue du Moulin, 57500', 'Éleveur'),
('13', 'Rousseau', '12 rue des Vignes, 57600', 'Vigneron'),
('14', 'Dubois', '15 rue de la Forge, 57540', 'Forgeron'),
('15', 'Lefèvre', '6 rue du Marché, 57520', 'Commerçant'),
('16', 'Lemoine', '9 avenue de la Gare, 57630', 'Chauffeur de Bus'),
('17', 'Girard', '18 rue de la Poste, 57510', 'Employé de Bureau'),
('18', 'Simon', '4 avenue de la Plage, 57550', 'Maître Nageur'),
('19', 'Fournier', '7 rue du Stade, 57650', 'Entraîneur Sportif'),
('20', 'Petit', '11 rue de lÉglise, 57660', 'Prêtre'),
('21', 'Lefort', '3 rue des Lilas, 57500', 'Fleuriste'),
('22', 'Martin', '10 avenue Victor Hugo, 57530', 'Restaurateur'),
('23', 'Renaud', '6 rue des Écoles, 57640', 'Enseignant'),
('24', 'Gauthier', '15 rue de la Mairie, 57510', 'Maire'),
('25', 'Robin', '20 rue des Artisans, 57620', 'Artisan'),
('26', 'Gonzalez', '12 avenue des Sports, 57560', 'Sportif'),
('27', 'Marchand', '9 rue du Commerce, 57550', 'Commerçant'),
('28', 'Dupuis', '5 rue de la Fontaine, 57630', 'Plombier'),
('29', 'Blanchard', '7 avenue de la République, 57600', 'Avocat'),
('30', 'Giraud', '14 rue du Château, 57540', 'Architecte');

-- --------------------------------------------------------

--
-- Structure de la table `commission`
--

DROP TABLE IF EXISTS `commission`;
CREATE TABLE IF NOT EXISTS `commission` (
  `code_cereale` int NOT NULL,
  `annee` date NOT NULL,
  `tx_site` int NOT NULL,
  `tx_st_adh` int NOT NULL,
  `prix_achat` int NOT NULL,
  PRIMARY KEY (`code_cereale`,`annee`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `commission`
--

INSERT INTO `commission` (`code_cereale`, `annee`, `tx_site`, `tx_st_adh`, `prix_achat`) VALUES
(1, '2023-01-01', 0, 0, 250),
(2, '2023-01-01', 0, 0, 200),
(3, '2023-01-01', 0, 0, 150),
(4, '2023-01-01', 0, 0, 275),
(5, '2023-01-01', 0, 0, 130),
(6, '2023-01-01', 0, 0, 135),
(7, '2023-01-01', 0, 0, 155),
(1, '2022-01-01', 3, 2, 200),
(2, '2022-01-01', 4, 3, 250),
(3, '2022-01-01', 2, 1, 180),
(4, '2022-01-01', 5, 4, 300),
(5, '2022-01-01', 3, 2, 220),
(6, '2022-01-01', 4, 3, 260),
(7, '2022-01-01', 2, 1, 190),
(8, '2022-01-01', 5, 4, 320),
(9, '2022-01-01', 3, 2, 240),
(1, '2024-01-01', 0, 0, 270),
(2, '2024-01-01', 0, 0, 210),
(3, '2024-01-01', 0, 0, 155),
(4, '2024-01-01', 0, 0, 285),
(5, '2024-01-01', 0, 0, 190),
(6, '2024-01-01', 0, 0, 220),
(7, '2024-01-01', 0, 0, 175),
(8, '2024-01-01', 0, 0, 245),
(9, '2024-01-01', 0, 0, 205);

-- --------------------------------------------------------

--
-- Structure de la table `contrat`
--

DROP TABLE IF EXISTS `contrat`;
CREATE TABLE IF NOT EXISTS `contrat` (
  `no_contrat` int NOT NULL,
  `date_contrat` date NOT NULL,
  `qte_prev` int NOT NULL,
  `qte_restante` int NOT NULL,
  `liv_immed` tinyint(1) NOT NULL,
  `date_liv_prev` date NOT NULL,
  `date_paiement` date NOT NULL,
  `no_adh` int NOT NULL,
  `code_cereale` int NOT NULL,
  PRIMARY KEY (`no_contrat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `contrat`
--

INSERT INTO `contrat` (`no_contrat`, `date_contrat`, `qte_prev`, `qte_restante`, `liv_immed`, `date_liv_prev`, `date_paiement`, `no_adh`, `code_cereale`) VALUES
(1, '2023-03-01', 1000, 1000, 1, '2023-03-31', '2023-03-31', 1, 1),
(2, '2022-02-07', 1000, 1000, 0, '2023-02-07', '2023-02-07', 2, 3),
(3, '2022-01-15', 1500, 0, 1, '2022-07-20', '2022-08-20', 3, 2),
(4, '2023-06-17', 3000, 3000, 0, '2023-07-10', '2023-11-10', 4, 5),
(5, '2022-05-12', 1000, 0, 1, '2023-01-09', '2023-01-09', 5, 1),
(6, '2021-09-22', 5000, 0, 0, '2021-10-10', '2021-10-10', 10, 5),
(7, '2023-03-15', 1000, 0, 1, '2023-03-16', '2023-03-31', 7, 6),
(8, '2023-01-27', 250, 100, 0, '2023-03-01', '2023-03-01', 4, 2),
(9, '2022-09-29', 500, 500, 0, '2023-04-21', '2023-03-21', 6, 7),
(10, '2020-11-30', 1000, 0, 1, '2021-02-06', '2021-02-06', 9, 7),
(11, '2022-05-13', 1000, 0, 1, '2022-07-13', '2023-03-31', 7, 2),
(12, '2023-03-01', 1000, 1000, 1, '2023-03-31', '2023-03-31', 1, 1),
(13, '2022-02-07', 1000, 1000, 0, '2023-02-07', '2023-02-07', 2, 3),
(14, '2022-01-15', 1500, 0, 1, '2022-07-20', '2022-08-20', 3, 2),
(15, '2023-06-17', 3000, 3000, 0, '2023-07-10', '2023-11-10', 4, 5),
(16, '2022-05-12', 1000, 0, 1, '2023-01-09', '2023-01-09', 5, 1),
(17, '2021-09-22', 5000, 0, 0, '2021-10-10', '2021-10-10', 10, 5),
(18, '2023-03-15', 1000, 0, 1, '2023-03-16', '2023-03-31', 7, 6),
(19, '2023-01-27', 250, 100, 0, '2023-03-01', '2023-03-01', 4, 2),
(20, '2022-09-29', 500, 500, 0, '2023-04-21', '2023-03-21', 6, 7),
(21, '2020-11-30', 1000, 0, 1, '2021-02-06', '2021-02-06', 9, 7);

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

DROP TABLE IF EXISTS `cours`;
CREATE TABLE IF NOT EXISTS `cours` (
  `code_cereale` int NOT NULL,
  `no_bourse` int NOT NULL,
  `date_cours` date NOT NULL,
  `tarif_tonne` int NOT NULL,
  PRIMARY KEY (`code_cereale`,`no_bourse`,`date_cours`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `cours`
--

INSERT INTO `cours` (`code_cereale`, `no_bourse`, `date_cours`, `tarif_tonne`) VALUES
(1, 1, '2023-01-01', 600),
(2, 2, '2023-01-01', 400),
(3, 3, '2023-01-01', 500),
(4, 4, '2023-01-01', 800),
(5, 5, '2023-01-01', 1000),
(6, 6, '2023-01-01', 650),
(7, 7, '2023-01-01', 500),
(211, 1, '2022-01-01', 620),
(212, 2, '2022-01-01', 410),
(213, 3, '2022-01-01', 520),
(214, 4, '2022-01-01', 809),
(215, 5, '2022-01-01', 1200),
(216, 6, '2022-01-01', 680),
(217, 7, '2022-01-01', 590),
(221, 1, '2022-02-01', 680),
(222, 2, '2022-02-01', 420),
(223, 3, '2022-02-01', 520),
(224, 4, '2022-02-01', 810),
(225, 5, '2022-02-01', 1200),
(226, 6, '2022-02-01', 630),
(227, 7, '2022-02-01', 530),
(231, 1, '2022-03-01', 620),
(232, 2, '2022-03-01', 450),
(233, 3, '2022-03-01', 580),
(234, 4, '2022-03-01', 890),
(235, 5, '2022-03-01', 1600),
(236, 6, '2022-03-01', 650),
(237, 7, '2022-03-01', 550),
(241, 1, '2022-04-01', 640),
(242, 2, '2022-04-01', 440),
(243, 3, '2022-04-01', 550),
(244, 4, '2022-04-01', 860),
(245, 5, '2022-04-01', 900),
(246, 6, '2022-04-01', 750),
(247, 7, '2022-04-01', 200),
(251, 1, '2022-05-01', 300),
(252, 2, '2022-05-01', 500),
(253, 3, '2022-05-01', 600),
(254, 4, '2022-05-01', 500),
(255, 5, '2022-05-01', 1100),
(256, 6, '2022-05-01', 610),
(257, 7, '2022-05-01', 800),
(261, 1, '2022-06-01', 620),
(262, 2, '2022-06-01', 430),
(263, 3, '2022-06-01', 550),
(264, 4, '2022-06-01', 820),
(265, 5, '2022-06-01', 1400),
(266, 6, '2022-06-01', 645),
(267, 7, '2022-06-01', 504),
(271, 1, '2022-07-01', 690),
(272, 2, '2022-07-01', 455),
(273, 3, '2022-07-01', 568),
(274, 4, '2022-07-01', 837),
(275, 5, '2022-07-01', 1050),
(276, 6, '2022-07-01', 656),
(277, 7, '2022-07-01', 510),
(281, 1, '2022-08-01', 620),
(282, 2, '2022-08-01', 430),
(283, 3, '2022-08-01', 570),
(284, 4, '2022-08-01', 880),
(285, 5, '2022-08-01', 1900),
(286, 6, '2022-08-01', 655),
(287, 7, '2022-08-01', 530),
(291, 1, '2022-09-01', 500),
(292, 2, '2022-09-01', 300),
(293, 3, '2022-09-01', 400),
(294, 4, '2022-09-01', 850),
(295, 5, '2022-09-01', 1200),
(296, 6, '2022-09-01', 620),
(297, 7, '2022-09-01', 530),
(2101, 1, '2022-10-01', 650),
(2102, 2, '2022-10-01', 490),
(2103, 3, '2022-10-01', 540),
(2104, 4, '2022-10-01', 830),
(2105, 5, '2022-10-01', 1600),
(2106, 6, '2022-10-01', 620),
(2107, 7, '2022-10-01', 520),
(2111, 1, '2022-11-01', 610),
(2112, 2, '2022-11-01', 410),
(2113, 3, '2022-11-01', 515),
(2114, 4, '2022-11-01', 869),
(2115, 5, '2022-11-01', 1023),
(2116, 6, '2022-11-01', 652),
(2117, 7, '2022-11-01', 550),
(2121, 1, '2022-12-01', 680),
(2122, 2, '2022-12-01', 470),
(2123, 3, '2022-12-01', 580),
(2124, 4, '2022-12-01', 870),
(2125, 5, '2022-12-01', 1250),
(2126, 6, '2022-12-01', 660),
(2127, 7, '2022-12-01', 535),
(2111, 11, '2022-01-01', 630),
(2122, 22, '2022-01-01', 450),
(2133, 33, '2022-01-01', 590),
(2144, 44, '2022-01-01', 889),
(2155, 55, '2022-01-01', 1800),
(2166, 66, '2022-01-01', 680),
(2177, 77, '2022-01-01', 580),
(2211, 11, '2022-02-01', 680),
(2222, 22, '2022-02-01', 480),
(2233, 33, '2022-02-01', 590),
(2244, 44, '2022-02-01', 890),
(2255, 55, '2022-02-01', 1900),
(2262, 66, '2022-02-01', 690),
(2277, 77, '2022-02-01', 590),
(2311, 11, '2022-03-01', 690),
(2321, 22, '2022-03-01', 450),
(2333, 33, '2022-03-01', 550),
(2344, 44, '2022-03-01', 850),
(2355, 55, '2022-03-01', 1500),
(2366, 66, '2022-03-01', 650),
(2377, 77, '2022-03-01', 540),
(2411, 11, '2022-04-01', 640),
(2422, 22, '2022-04-01', 440),
(2433, 33, '2022-04-01', 540),
(2444, 44, '2022-04-01', 830),
(2455, 55, '2022-04-01', 930),
(2466, 66, '2022-04-01', 730),
(2477, 77, '2022-04-01', 220),
(2511, 11, '2022-05-01', 320),
(2522, 22, '2022-05-01', 520),
(2533, 33, '2022-05-01', 620),
(2544, 4, '2022-05-01', 502),
(2555, 55, '2022-05-01', 1200),
(2566, 66, '2022-05-01', 610),
(2577, 77, '2022-05-01', 800),
(2611, 11, '2022-06-01', 620),
(2622, 22, '2022-06-01', 430),
(2633, 33, '2022-06-01', 500),
(2644, 44, '2022-06-01', 800),
(2655, 55, '2022-06-01', 1000),
(2666, 66, '2022-06-01', 605),
(2677, 77, '2022-06-01', 504),
(2711, 11, '2022-07-01', 610),
(2722, 22, '2022-07-01', 415),
(2733, 33, '2022-07-01', 518),
(2744, 44, '2022-07-01', 817),
(2755, 55, '2022-07-01', 1150),
(2766, 66, '2022-07-01', 696),
(2777, 77, '2022-07-01', 590),
(2811, 11, '2022-08-01', 690),
(2822, 22, '2022-08-01', 490),
(2833, 33, '2022-08-01', 590),
(2844, 44, '2022-08-01', 890),
(2855, 55, '2022-08-01', 1100),
(2866, 66, '2022-08-01', 615),
(2877, 77, '2022-08-01', 510),
(2911, 11, '2022-09-01', 510),
(2922, 22, '2022-09-01', 300),
(2933, 33, '2022-09-01', 400),
(2944, 44, '2022-09-01', 800),
(2955, 55, '2022-09-01', 1000),
(2966, 66, '2022-09-01', 600),
(2977, 77, '2022-09-01', 500),
(21011, 11, '2022-10-01', 650),
(21022, 22, '2022-10-01', 460),
(21033, 33, '2022-10-01', 560),
(21044, 44, '2022-10-01', 860),
(21055, 55, '2022-10-01', 1600),
(21066, 66, '2022-10-01', 660),
(21077, 77, '2022-10-01', 530),
(21111, 11, '2022-11-01', 630),
(21122, 22, '2022-11-01', 430),
(21133, 33, '2022-11-01', 535),
(21144, 44, '2022-11-01', 839),
(21155, 55, '2022-11-01', 1223),
(21166, 66, '2022-11-01', 622),
(21177, 77, '2022-11-01', 520),
(21211, 11, '2022-12-01', 620),
(21222, 22, '2022-12-01', 470),
(21233, 33, '2022-12-01', 570),
(21244, 44, '2022-12-01', 870),
(21255, 55, '2022-12-01', 1750),
(21266, 66, '2022-12-01', 670),
(21277, 77, '2022-12-01', 575);

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

DROP TABLE IF EXISTS `facture`;
CREATE TABLE IF NOT EXISTS `facture` (
  `no_fact` int NOT NULL,
  `date_fact` date NOT NULL,
  `date_encais` date NOT NULL,
  `num_marche` int NOT NULL,
  PRIMARY KEY (`no_fact`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `facture`
--

INSERT INTO `facture` (`no_fact`, `date_fact`, `date_encais`, `num_marche`) VALUES
(1, '2023-01-20', '2023-01-24', 1),
(2, '2023-01-26', '2023-02-02', 2),
(3, '2023-02-20', '2023-02-24', 3),
(4, '2023-02-24', '2023-02-27', 4),
(5, '2023-02-15', '2023-02-23', 5),
(6, '2023-03-22', '2023-04-12', 6),
(7, '2023-03-22', '2023-04-06', 7),
(8, '2023-04-15', '2023-04-15', 8),
(9, '2023-04-13', '2023-04-15', 9),
(10, '2023-05-01', '2023-05-05', 10),
(11, '2023-05-10', '2023-05-12', 11),
(12, '2023-05-15', '2023-05-18', 12),
(13, '2023-05-20', '2023-05-24', 13),
(14, '2023-05-25', '2023-05-28', 14),
(15, '2023-05-02', '2023-05-06', 15),
(16, '2023-05-08', '2023-05-12', 16),
(17, '2023-05-14', '2023-05-18', 17),
(18, '2023-05-20', '2023-05-24', 18),
(19, '2023-05-26', '2023-05-30', 19);

-- --------------------------------------------------------

--
-- Structure de la table `marche`
--

DROP TABLE IF EXISTS `marche`;
CREATE TABLE IF NOT EXISTS `marche` (
  `num_marche` int NOT NULL,
  `date_marche` date NOT NULL,
  `qte_cdee` int NOT NULL,
  `prix_vente` int NOT NULL,
  `date_liv_prev` date NOT NULL,
  `type_liv` varchar(20) NOT NULL,
  `num_cl` varchar(20) NOT NULL,
  `code_cereale` int NOT NULL,
  PRIMARY KEY (`num_marche`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `marche`
--

INSERT INTO `marche` (`num_marche`, `date_marche`, `qte_cdee`, `prix_vente`, `date_liv_prev`, `type_liv`, `num_cl`, `code_cereale`) VALUES
(1, '2023-01-20', 100, 250, '2023-01-25', 'Camion', '1', 1),
(2, '2023-01-26', 300, 250, '2023-01-31', 'Camion', '3', 1),
(3, '2023-02-20', 150, 200, '2023-02-24', 'Camion', '4', 2),
(4, '2023-02-24', 500, 100, '2023-03-24', 'Bateau', '5', 2),
(5, '2023-02-15', 10000, 80, '2023-04-14', 'Train', '6', 1),
(6, '2023-03-22', 100, 350, '2023-03-31', 'Train', '3', 7),
(7, '2023-03-22', 200, 550, '2023-03-30', 'Bateau', '3', 6),
(8, '2023-03-23', 50, 275, '2023-03-31', 'Camion', '3', 1),
(9, '2023-04-13', 45, 350, '2023-04-29', 'Train', '5', 4),
(10, '2023-05-01', 200, 300, '2023-05-10', 'Camion', '2', 3),
(11, '2023-05-10', 300, 250, '2023-05-18', 'Camion', '1', 2),
(12, '2023-05-15', 150, 200, '2023-05-20', 'Bateau', '4', 3),
(13, '2023-05-20', 500, 100, '2023-05-30', 'Train', '6', 4),
(14, '2023-05-25', 10000, 80, '2023-06-05', 'Camion', '5', 1),
(15, '2023-05-02', 100, 350, '2023-05-15', 'Train', '3', 6),
(16, '2023-05-08', 200, 550, '2023-05-17', 'Bateau', '3', 7),
(17, '2023-05-14', 50, 275, '2023-05-25', 'Camion', '3', 1),
(18, '2023-05-20', 45, 350, '2023-05-31', 'Train', '5', 4),
(19, '2023-05-26', 150, 200, '2023-06-02', 'Camion', '2', 2);

-- --------------------------------------------------------

--
-- Structure de la table `pai_contrat`
--

DROP TABLE IF EXISTS `pai_contrat`;
CREATE TABLE IF NOT EXISTS `pai_contrat` (
  `no_paiement` int NOT NULL,
  `date_pai` date NOT NULL,
  `mt` int NOT NULL,
  `no_contrat` int NOT NULL,
  PRIMARY KEY (`no_paiement`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `pai_contrat`
--

INSERT INTO `pai_contrat` (`no_paiement`, `date_pai`, `mt`, `no_contrat`) VALUES
(1, '2023-01-09', 20000, 5),
(2, '2023-02-20', 27500, 3),
(3, '2023-03-07', 200000, 5);

-- --------------------------------------------------------

--
-- Structure de la table `site`
--

DROP TABLE IF EXISTS `site`;
CREATE TABLE IF NOT EXISTS `site` (
  `code_site` int NOT NULL,
  PRIMARY KEY (`code_site`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `site`
--

INSERT INTO `site` (`code_site`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12);
-- --------------------------------------------------------

--
-- Structure de la table `sortie`
--

DROP TABLE IF EXISTS `sortie`;
CREATE TABLE IF NOT EXISTS `sortie` (
  `num_marche` int NOT NULL,
  `code_site` int NOT NULL,
  `date_sortie` date NOT NULL,
  `qte_sortie` int NOT NULL,
  PRIMARY KEY (`num_marche`,`code_site`,`date_sortie`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `sortie`
--

INSERT INTO `sortie` (`num_marche`, `code_site`, `date_sortie`, `qte_sortie`) VALUES
(1, 5, '2023-01-25', 100),
(2, 5, '2023-01-31', 300),
(3, 3, '2023-02-24', 150),
(4, 3, '2023-03-01', 500),
(5, 2, '2023-04-10', 10000),
(6, 2, '2023-04-12', 100),
(7, 2, '2023-04-06', 200),
(8, 1, '2023-04-15', 50),
(9, 3, '2023-04-15', 45),
(10, 4, '2023-05-05', 200),
(11, 4, '2023-05-12', 300),
(12, 3, '2023-05-18', 150),
(13, 3, '2023-05-24', 500),
(14, 2, '2023-05-28', 10000),
(15, 2, '2023-05-30', 100),
(16, 2, '2023-05-25', 200),
(17, 1, '2023-05-15', 50),
(18, 3, '2023-05-15', 45),
(19, 4, '2023-05-31', 150);

-- --------------------------------------------------------

--
-- Structure de la table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE IF NOT EXISTS `stock` (
  `code_site` int NOT NULL,
  `code_cereale` int NOT NULL,
  `annee` date NOT NULL,
  `peut_recevoir` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `st_res` int NOT NULL,
  `st_ajust` int NOT NULL,
  PRIMARY KEY (`code_site`,`code_cereale`,`annee`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `stock`
--

INSERT INTO `stock` (`code_site`, `code_cereale`, `annee`, `peut_recevoir`, `st_res`, `st_ajust`) VALUES
(5, 1, '2023-01-09', '5000', 1000, 950),
(3, 2, '2023-02-20', '10000', 1500, 1490),
(5, 1, '2023-01-25', '10000', 850, 845),
(5, 1, '2023-01-31', '10000', 545, 540),
(3, 2, '2023-02-24', '10000', 1350, 1300),
(3, 2, '2023-03-01', '10000', 800, 780),
(4, 3, '2023-05-05', '15000', 1200, 1180),
(5, 1, '2023-05-12', '20000', 950, 930),
(3, 2, '2023-05-18', '18000', 1490, 1450),
(3, 2, '2023-05-24', '18000', 1300, 1260),
(2, 1, '2023-05-28', '25000', 540, 530),
(2, 1, '2023-05-30', '25000', 420, 400),
(2, 1, '2023-05-25', '25000', 600, 580),
(1, 3, '2023-05-15', '15000', 780, 750),
(3, 2, '2023-05-15', '18000', 900, 880),
(4, 3, '2023-05-31', '15000', 1450, 1420);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

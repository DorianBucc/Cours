import { Departement } from "./Departement.ts";
import { Matiere } from "./Matiere.ts";

export class Enseignant {

    private _nom!: string;
    private _prenom!: string;
    private _volumesHoraire: Map<Departement, Map<Matiere, number>>;

    public constructor(nom: string, prenom: string) {
        this.nom = nom;
        this.prenom = prenom;
        this._volumesHoraire = new Map<Departement, Map<Matiere, number>>();
    }

    public ajouteVolumeHoraire(departement: Departement, matiere: Matiere, volumeHoraire: number): void {
        const listeMatieresDpt = this._volumesHoraire.get(departement);

        if (listeMatieresDpt===undefined) {
            const listeMatieres = new Map<Matiere, number>();
            listeMatieres.set(matiere, volumeHoraire);
            this._volumesHoraire.set(departement, listeMatieres);
        } else {
            const actuel = listeMatieresDpt.get(matiere);
            if (actuel===undefined) {
                listeMatieresDpt.set(matiere, volumeHoraire);
            } else {
                listeMatieresDpt.set(matiere, actuel  + volumeHoraire);
            }
        }
    }

    public retireVolumeHoraire(departement: Departement, matiere: Matiere, volumeHoraire: number): void {
        const listeMatieresDpt = this._volumesHoraire.get(departement);
        if (listeMatieresDpt===undefined) {
            throw new Error("Aucune heure n'est faite dans ce département !");
        }
        const actuel = listeMatieresDpt.get(matiere);
        if (actuel===undefined) {
            throw new Error("Aucune heure n'est faite dans cette matière pour ce département !");
        }
        else if (actuel===volumeHoraire) {
            listeMatieresDpt.delete(matiere);
            if (listeMatieresDpt.size===0) {
                this._volumesHoraire.delete(departement);
            }
        } else if (actuel < volumeHoraire) {
            throw new Error("Le volume horaire à retirer est supérieur au volume horaire actuel !");
        } else {
            listeMatieresDpt.set(matiere, actuel - volumeHoraire);
        }
    }

    public get volumeHoraire(): Map<Departement, Map<Matiere, number>> {
        return this._volumesHoraire;
    }

    public volumeHoraireToString(): string {
        let res = "";
        for (const [departement, listeMatieres] of this._volumesHoraire) {
            res += departement.toString() + " :\n";
            for (const [matiere, volume] of listeMatieres) {
                res+= "\t" + matiere.toString() + " : " + volume + "\n";
            }
        }
        return res;
    }

    public set nom(nom: string) {
        nom = nom.trim().toUpperCase();
        if (nom.length < 2) {
            throw new Error("Le nom de l'enseignant doit contenir au moins 2 caractères");
        }
        this._nom = nom;
    }
    
    public get nom(): string {
        return this._nom;
    }
    
    public set prenom(prenom: string) {
        prenom = prenom.trim();
        if (prenom.length < 2) {
            throw new Error("Le prénom de l'enseignant doit contenir au moins 2 caractères");
        }
        this._prenom = prenom;
    }
    
    public get prenom(): string {
        return this._prenom;
    }

    public toString(): string {
        return this._nom + " " + this._prenom;
    }
}
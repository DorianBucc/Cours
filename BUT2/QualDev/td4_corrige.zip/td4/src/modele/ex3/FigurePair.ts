import { ICalculateurAire } from "./ICalculateurAire.ts";

export class FigurePair<T extends ICalculateurAire> {
  private _first!: T;
  private _second!: T;

  constructor(first: T, second: T) {
    this.first = first;
    this.second = second;
  }

  public get first(): T {
    return this._first;
  }

  public set first(first: T) {
    this._first = first;
  }

  public get second(): T {
    return this._second;
  }

  public set second(second: T) {
    this._second = second;
  }

  public aireTotale(): number {
    return this._first.getAire() + this._second.getAire();
  }
}

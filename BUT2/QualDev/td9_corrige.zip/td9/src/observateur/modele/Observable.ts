import { IObserver } from "./IObserver.ts";

export abstract class Observable {

    private _observateurs : IObserver[];

    protected constructor() {
        this._observateurs = [];
    }
    
    public ajouteObservateur(obs : IObserver) : void {

        if (!this._observateurs.includes(obs)) {
            this._observateurs.push(obs);
        }
    }

    public supprimeObservateur(obs : IObserver) : void {

        const idx = this._observateurs.indexOf(obs);
        if (idx !==-1) {
            this._observateurs.splice(idx, 1);
        }
    }

    public notifyObservers(): void {

        for (const observateur of this._observateurs) {
            observateur.notify(this);
        }
        
    }

}
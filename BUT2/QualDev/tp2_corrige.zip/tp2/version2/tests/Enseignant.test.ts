import { Enseignant } from "../src/modele/Enseignant.ts";
import { Departement } from "../src/modele/Departement.ts";
import { Matiere } from "../src/modele/Matiere.ts";
import { assertEquals, assertThrows } from "https://deno.land/std@0.201.0/assert/mod.ts";

function setUp(): Enseignant {
  const enseignant = new Enseignant("Zsuzsanna", "Roka");
  return enseignant;
}

Deno.test("Volume horaire vide à la création", () => {
  const enseignant = setUp();
  assertEquals(enseignant.volumeHoraire.size, 0);
});

Deno.test("Ajout volume horaire département inexistant", () => {
  const enseignant = setUp();
  const dpt = new Departement("INFO");
  const mati = new Matiere("IN01", "Programmation PHP");
  
  enseignant.ajouteVolumeHoraire(dpt, mati, 10);
  assertEquals(enseignant.volumeHoraire.size, 1);
  assertEquals(enseignant.volumeHoraire.keys().next().value, dpt);
  assertEquals(enseignant.volumeHoraire.get(dpt)!.size, 1);
  assertEquals(enseignant.volumeHoraire.get(dpt)!.keys().next().value, mati);
  assertEquals(enseignant.volumeHoraire.get(dpt)!.get(mati), 10);
});

Deno.test("Ajout volume horaire département existant matiere existante", () => {
  const enseignant = setUp();
  const dpt = new Departement("INFO");
  const mati = new Matiere("IN01", "Programmation PHP");
  
  enseignant.ajouteVolumeHoraire(dpt, mati, 10);
  enseignant.ajouteVolumeHoraire(dpt, mati, 30);
  assertEquals(enseignant.volumeHoraire.get(dpt)!.size, 1);
  assertEquals(enseignant.volumeHoraire.get(dpt)!.get(mati), 40);
});

Deno.test("Ajout volume horaire département existant matiere nouvelle", () => {
  const enseignant = setUp();
  const dpt = new Departement("INFO");
  const mati = new Matiere("IN01", "Programmation PHP");  
  enseignant.ajouteVolumeHoraire(dpt, mati, 10);
  const mati2 = new Matiere("IN02", "Javascript");  
  enseignant.ajouteVolumeHoraire(dpt, mati2, 20);
  
  assertEquals(enseignant.volumeHoraire.size, 1);
  assertEquals(enseignant.volumeHoraire.get(dpt)!.size, 2);
  assertEquals(enseignant.volumeHoraire.get(dpt)!.get(mati), 10);
  assertEquals(enseignant.volumeHoraire.get(dpt)!.get(mati2), 20);
});

Deno.test("Ajout volume horaire deux départements inexistants", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    const dpt2 = new Departement("GMP");
    const mati = new Matiere("IN01", "Programmation PHP");  
    const mati2 = new Matiere("IN02", "Javascript");  
    
    enseignant.ajouteVolumeHoraire(dpt1, mati, 10);
    enseignant.ajouteVolumeHoraire(dpt2, mati2, 20);
    assertEquals(enseignant.volumeHoraire.size, 2);
    assertEquals(enseignant.volumeHoraire.get(dpt1)!.size, 1);
    assertEquals(enseignant.volumeHoraire.get(dpt2)!.size, 1);
    assertEquals(enseignant.volumeHoraire.get(dpt1)!.get(mati), 10);
    assertEquals(enseignant.volumeHoraire.get(dpt2)!.get(mati2), 20);
  });

  Deno.test("Retrait volume horaire département inexistant", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    const mati = new Matiere("IN01", "Programmation PHP");  

    assertThrows(()=>enseignant.retireVolumeHoraire(dpt1, mati, 8));
  });

  Deno.test("Retrait volume horaire département existant avec reste", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    const mati = new Matiere("IN01", "Programmation PHP");  

    enseignant.ajouteVolumeHoraire(dpt1, mati, 10);
    enseignant.retireVolumeHoraire(dpt1, mati, 8);
    assertEquals(enseignant.volumeHoraire.size, 1);
    assertEquals(enseignant.volumeHoraire.get(dpt1)!.get(mati), 2);
  });

  Deno.test("Retrait volume horaire un seul département existant sans reste", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    const mati = new Matiere("IN01", "Programmation PHP");  

    enseignant.ajouteVolumeHoraire(dpt1, mati, 10);
    
    enseignant.retireVolumeHoraire(dpt1, mati, 10);
    assertEquals(enseignant.volumeHoraire.size, 0);
  });

  Deno.test("Retrait volume horaire plusieurs départements existants, dont un sans reste", () => {
    const enseignant = setUp();
    
    const dpt1 = new Departement("INFO");
    const mat1 = new Matiere("IN01", "Programmation PHP");  
    enseignant.ajouteVolumeHoraire(dpt1, mat1, 10);
    
    const dpt2 = new Departement("GMP");
    const mat2 = new Matiere("IN01", "Programmation PHP");  
    enseignant.ajouteVolumeHoraire(dpt2, mat2, 30);
    
    enseignant.retireVolumeHoraire(dpt1, mat1, 10);
    assertEquals(enseignant.volumeHoraire.has(dpt1), false);
    assertEquals(enseignant.volumeHoraire.size, 1);
  });


  Deno.test("Retrait volume horaire département existant, trop important", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    const mati = new Matiere("IN01", "Programmation PHP");  
      
    enseignant.ajouteVolumeHoraire(dpt1, mati, 10);
    assertThrows(()=> enseignant.retireVolumeHoraire(dpt1, mati, 11));
  });

  Deno.test("Retrait volume horaire département/matière inexistant", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    const mati = new Matiere("IN01", "Programmation PHP");  

    assertThrows(()=> enseignant.retireVolumeHoraire(dpt1, mati, 10));
  });

  Deno.test("Retrait volume horaire département existant mais matière inexistant", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    const mat1 = new Matiere("IN01", "Programmation PHP");  
    enseignant.ajouteVolumeHoraire(dpt1, mat1, 10);
    const mat2 = new Matiere("IN02", "Javascript");  

    assertThrows(()=> enseignant.retireVolumeHoraire(dpt1, mat2, 10));
  });

  Deno.test("volumeHoraireToString vide", () => {
    const enseignant = setUp();
    assertEquals(enseignant.volumeHoraireToString(), "");
  });

  Deno.test("volumeHoraireToString non vide", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    const dpt2 = new Departement("GMP");
    const mat1 = new Matiere("IN01", "Programmation PHP");  
    const mat2 = new Matiere("IN02", "Javascript");  
    
    enseignant.ajouteVolumeHoraire(dpt1, mat1, 10);
    enseignant.ajouteVolumeHoraire(dpt2, mat2, 20);
    assertEquals(enseignant.volumeHoraireToString(), "INFO :\n\tProgrammation PHP : 10\nGMP :\n\tJavascript : 20\n");
  });


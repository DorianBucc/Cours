-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 18 jan. 2023 à 20:23
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `cooperative_agricolev1`
--

-- --------------------------------------------------------

--
-- Structure de la table `adherent`
--

DROP TABLE IF EXISTS `adherent`;
CREATE TABLE IF NOT EXISTS `adherent` (
  `id_ad` int(100) NOT NULL,
  `nom_ad` varchar(40) NOT NULL,
  `id_adresse` int(11) NOT NULL,
  PRIMARY KEY (`id_ad`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `adherent`
--

INSERT INTO `adherent` (`id_ad`, `nom_ad`, `id_adresse`) VALUES
(1, 'Michelle', 1157070),
(2, 'Dupont', 1255600),
(3, 'Golmard', 1357730),
(4, 'Pierre', 1258465),
(5, 'Anthony', 9865471),
(6, 'Jacques', 1224576);

-- --------------------------------------------------------

--
-- Structure de la table `adresse`
--

DROP TABLE IF EXISTS `adresse`;
CREATE TABLE IF NOT EXISTS `adresse` (
  `id_adresse` int(100) NOT NULL,
  `adresse` varchar(40) NOT NULL,
  PRIMARY KEY (`id_adresse`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `adresse`
--

INSERT INTO `adresse` (`id_adresse`, `adresse`) VALUES
(1157070, 'Metz, Borny'),
(1057530, 'Courcelles-Chaussy'),
(1255600, 'Reims'),
(1357730, 'Bitche');

-- --------------------------------------------------------

--
-- Structure de la table `avenant`
--

DROP TABLE IF EXISTS `avenant`;
CREATE TABLE IF NOT EXISTS `avenant` (
  `id_gestion_avenant` int(11) NOT NULL,
  `id_gestion_remplacent` int(11) NOT NULL,
  PRIMARY KEY (`id_gestion_avenant`,`id_gestion_remplacent`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `avenant`
--

INSERT INTO `avenant` (`id_gestion_avenant`, `id_gestion_remplacent`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 6);

-- --------------------------------------------------------

--
-- Structure de la table `cereale`
--

DROP TABLE IF EXISTS `cereale`;
CREATE TABLE IF NOT EXISTS `cereale` (
  `id_cereale` int(100) NOT NULL,
  `nom_cereale` varchar(40) NOT NULL,
  PRIMARY KEY (`id_cereale`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cereale`
--

INSERT INTO `cereale` (`id_cereale`, `nom_cereale`) VALUES
(1, 'Blé'),
(2, 'Orge'),
(3, 'Maïs'),
(4, 'Avoine');

-- --------------------------------------------------------

--
-- Structure de la table `changement`
--

DROP TABLE IF EXISTS `changement`;
CREATE TABLE IF NOT EXISTS `changement` (
  `id_liv_modifier` int(11) NOT NULL,
  `id_liv_remplacant` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `changement`
--

INSERT INTO `changement` (`id_liv_modifier`, `id_liv_remplacant`) VALUES
(111, 114),
(112, 115),
(113, 116),
(113, 116),
(114, 117);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id_cl` int(100) NOT NULL,
  `nom_cl` varchar(100) NOT NULL,
  `categ_cl` varchar(100) NOT NULL,
  `nationalite_cl` varchar(100) NOT NULL,
  `RIB` varchar(100) NOT NULL,
  `id_adresse` int(11) NOT NULL,
  PRIMARY KEY (`id_cl`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id_cl`, `nom_cl`, `categ_cl`, `nationalite_cl`, `RIB`, `id_adresse`) VALUES
(1, 'Jacques', 'habituelle', 'français', 'FR1421422176217032', 1),
(2, 'Pierre', 'prospecte', 'français', 'FR1421422176217042', 2),
(3, 'Henry', 'prospecte', 'français', 'FR1421422176217052', 3),
(4, 'Jacob', 'habituelle', 'espagnol', 'FR1421422176217062', 5);

-- --------------------------------------------------------

--
-- Structure de la table `contrat`
--

DROP TABLE IF EXISTS `contrat`;
CREATE TABLE IF NOT EXISTS `contrat` (
  `id_contrat` int(100) NOT NULL,
  `montant_avance` decimal(65,0) NOT NULL,
  `id_cereale` int(11) NOT NULL,
  `id_gestion` int(11) NOT NULL,
  `id_ad` int(11) NOT NULL,
  PRIMARY KEY (`id_contrat`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `contrat`
--

INSERT INTO `contrat` (`id_contrat`, `montant_avance`, `id_cereale`, `id_gestion`, `id_ad`) VALUES
(1, '1500', 1, 1, 1),
(2, '1000', 2, 2, 2),
(3, '1400', 3, 3, 3);

-- --------------------------------------------------------

--
-- Structure de la table `contrat_inscription`
--

DROP TABLE IF EXISTS `contrat_inscription`;
CREATE TABLE IF NOT EXISTS `contrat_inscription` (
  `id_inscrit` int(100) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `id_ad` int(11) NOT NULL,
  PRIMARY KEY (`id_inscrit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `contrat_inscription`
--

INSERT INTO `contrat_inscription` (`id_inscrit`, `date_debut`, `date_fin`, `id_ad`) VALUES
(1, '2022-01-16', '2023-01-16', 1),
(2, '2021-05-10', '2022-05-17', 2),
(3, '2021-03-11', '2022-03-17', 3);

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

DROP TABLE IF EXISTS `facture`;
CREATE TABLE IF NOT EXISTS `facture` (
  `id_facturation` int(100) NOT NULL,
  `montant_fac` int(100) NOT NULL,
  `date_fac` date NOT NULL,
  `id_marche` int(11) NOT NULL,
  PRIMARY KEY (`id_facturation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `facture`
--

INSERT INTO `facture` (`id_facturation`, `montant_fac`, `date_fac`, `id_marche`) VALUES
(1, 1000, '2022-07-16', 1),
(2, 1500, '2021-04-24', 2),
(3, 1800, '2023-01-01', 3);

-- --------------------------------------------------------

--
-- Structure de la table `gestion`
--

DROP TABLE IF EXISTS `gestion`;
CREATE TABLE IF NOT EXISTS `gestion` (
  `id_gestion` int(100) NOT NULL,
  `type_liv` varchar(40) NOT NULL,
  `date_c` date NOT NULL,
  `qte_c` int(100) NOT NULL,
  PRIMARY KEY (`id_gestion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `gestion`
--

INSERT INTO `gestion` (`id_gestion`, `type_liv`, `date_c`, `qte_c`) VALUES
(1, 'Partielle', '2023-01-18', 500),
(2, 'Partielle', '2022-05-12', 200);

-- --------------------------------------------------------

--
-- Structure de la table `livraison`
--

DROP TABLE IF EXISTS `livraison`;
CREATE TABLE IF NOT EXISTS `livraison` (
  `id_liv` int(100) NOT NULL,
  `date_liv` date NOT NULL,
  `qte_liv` int(100) NOT NULL,
  `adr_liv` int(100) NOT NULL,
  `id_gestion` int(11) NOT NULL,
  PRIMARY KEY (`id_liv`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `livraison`
--

INSERT INTO `livraison` (`id_liv`, `date_liv`, `qte_liv`, `adr_liv`, `id_gestion`) VALUES
(111, '2023-01-10', 250, 1157070, 1),
(112, '2023-01-01', 100, 1157070, 2),
(113, '2022-04-05', 200, 1057530, 3);

-- --------------------------------------------------------

--
-- Structure de la table `marche`
--

DROP TABLE IF EXISTS `marche`;
CREATE TABLE IF NOT EXISTS `marche` (
  `id_marche` int(100) NOT NULL,
  `taux_com` int(100) NOT NULL,
  `avance_finance` int(100) NOT NULL,
  `prix` int(100) NOT NULL,
  `id_gestion` int(11) NOT NULL,
  `id_cl` int(11) NOT NULL,
  PRIMARY KEY (`id_marche`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `marche`
--

INSERT INTO `marche` (`id_marche`, `taux_com`, `avance_finance`, `prix`, `id_gestion`, `id_cl`) VALUES
(1, 10, 200, 200, 1, 1),
(2, 20, 500, 400, 2, 2),
(3, 20, 400, 200, 3, 3);

-- --------------------------------------------------------

--
-- Structure de la table `site`
--

DROP TABLE IF EXISTS `site`;
CREATE TABLE IF NOT EXISTS `site` (
  `id_site` int(100) NOT NULL,
  `nom_site` varchar(100) NOT NULL,
  PRIMARY KEY (`id_site`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `site`
--

INSERT INTO `site` (`id_site`, `nom_site`) VALUES
(1, 'Jean-de-la-tour'),
(2, 'Maurice-232'),
(3, 'ARCO');

-- --------------------------------------------------------

--
-- Structure de la table `stock_adhérent`
--

DROP TABLE IF EXISTS `stock_adhérent`;
CREATE TABLE IF NOT EXISTS `stock_adhérent` (
  `id_ad` int(11) NOT NULL,
  `id_cereale` int(11) NOT NULL,
  `qte_stock_ad` int(11) NOT NULL,
  PRIMARY KEY (`id_ad`,`id_cereale`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `stock_adhérent`
--

INSERT INTO `stock_adhérent` (`id_ad`, `id_cereale`, `qte_stock_ad`) VALUES
(1, 3, 50),
(2, 2, 200),
(3, 3, 400),
(3, 1, 300);

-- --------------------------------------------------------

--
-- Structure de la table `stock_sur_site`
--

DROP TABLE IF EXISTS `stock_sur_site`;
CREATE TABLE IF NOT EXISTS `stock_sur_site` (
  `id_site` int(11) NOT NULL,
  `id_cereale` int(11) NOT NULL,
  `qte_stock` int(11) NOT NULL,
  PRIMARY KEY (`id_site`,`id_cereale`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `stock_sur_site`
--

INSERT INTO `stock_sur_site` (`id_site`, `id_cereale`, `qte_stock`) VALUES
(1, 2, 200),
(3, 2, 500),
(2, 1, 400),
(1, 4, 800);

-- --------------------------------------------------------

--
-- Structure de la table `type_client`
--

DROP TABLE IF EXISTS `type_client`;
CREATE TABLE IF NOT EXISTS `type_client` (
  `id_type_cl` int(100) NOT NULL,
  `nom_type_cl` varchar(100) NOT NULL,
  PRIMARY KEY (`id_type_cl`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `type_client`
--

INSERT INTO `type_client` (`id_type_cl`, `nom_type_cl`) VALUES
(2, 'Scierie'),
(1, 'Menuiserie'),
(3, 'Restaurant');

-- --------------------------------------------------------

--
-- Structure de la table `type_transport`
--

DROP TABLE IF EXISTS `type_transport`;
CREATE TABLE IF NOT EXISTS `type_transport` (
  `id_type_liv` int(100) NOT NULL,
  `label_type_liv` varchar(100) NOT NULL,
  PRIMARY KEY (`id_type_liv`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `type_transport`
--

INSERT INTO `type_transport` (`id_type_liv`, `label_type_liv`) VALUES
(1110111, 'Train 100 Tonnes'),
(1110112, 'Train 1000 Tonnes'),
(55501, 'Semi-remorque 24 Tonnes'),
(55519, 'Semi-remorque 62 Tonnes');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

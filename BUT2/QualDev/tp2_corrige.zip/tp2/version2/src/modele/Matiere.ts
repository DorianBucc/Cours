export class Matiere {

    private _code! : string;
    private _libelle! : string;

    public constructor(code: string, libelle: string) {
        this.code = code;
        this.libelle = libelle;
    }

    public set code(code: string) {
        code = code.trim().toUpperCase();
        if (code.length !== 4) {
            throw new Error("Le code de la matière doit contenir 4 caractères");
        }
        this._code = code;
    }

    public get code(): string {
        return this._code;
    }

    public set libelle(libelle: string) {
        libelle = libelle.trim();
        if (libelle.length < 6) {
            throw new Error("Le libellé de la matière doit contenir au moins 6 caractères");
        }
        this._libelle = libelle;
    }

    public get libelle(): string {
        return this._libelle;
    }
    public toString(): string {
        return this._libelle;
    }
}
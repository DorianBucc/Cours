import { Epreuve } from "./Epreuve.ts";
import { TypeEpreuve } from "./TypeEpreuve.ts";

export class Lancer extends Epreuve {
  constructor(nom: string) {
    super(nom, "mètres", TypeEpreuve.Lancer);
  }
}

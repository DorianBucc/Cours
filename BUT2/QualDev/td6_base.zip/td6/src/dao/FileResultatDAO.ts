import { Athlete } from "../modele/Athlete.ts";
import { Epreuve } from "../modele/epreuves/Epreuve.ts";
import { Resultat } from "../modele/resultats/Resultat.ts";

export class FileResultatDAO {
  public static async chargeResultats(
    dossier: string,
    athletes: Athlete[],
    epreuves: Epreuve[],
  ): Promise<Resultat[]> {
    const liste: Resultat[] = [];
    const donnees = await Deno.readTextFile(
      "./src/donnees/" + dossier + "/resultats.txt",
    );

    const lignes = donnees.split("\n");

    for (const ligne of lignes) {
      if (ligne.trim().length !== 0) {
        const infoResultat = ligne.split(";");
        const athlete = athletes.filter((item) =>
          item.dossard === Number.parseInt(infoResultat[0])
        )[0];
        const epreuve = epreuves.filter((item) =>
          item.nom === infoResultat[1]
        )[0];
        const resultat = new Resultat(
          athlete,
          epreuve,
          Number.parseFloat(infoResultat[2]),
        );
        liste.push(resultat);
      }
    }

    return liste;
  }

  public static async sauveResultats(
    dossier: string,
    resultats: Resultat[],
  ): Promise<void> {
    const fd = await Deno.open("./src/donnees/" + dossier + "/resultats.txt", {
      write: true,
    });

    const encoder = new TextEncoder();
    for (const resultat of resultats) {
      const ligne = resultat.athlete.dossard + ";" + resultat.epreuve.nom +
        ";" + resultat.resultat + "\n";
      Deno.write(fd.rid, encoder.encode(ligne));
    }
    Deno.close(fd.rid);
  }
}

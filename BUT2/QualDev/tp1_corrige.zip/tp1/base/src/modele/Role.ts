export class Role {
  private _description!: string;
  private static readonly _valeursPossibles = [
    "groupe",
    "auteur principal",
    "auteur",
    "compositeur",
    "traducteur",
    "dessinateur",
    "scénariste",
  ];

  public constructor(description: string) {
    this.description = description;
  }

  public set description(description: string) {
    description = description.toLowerCase().trim();
    if (Role._valeursPossibles.includes(description)) {
      this._description = description;
    } else {
      throw new Error("Valeur de description de rôle interdite !");
    }
  }

  public get description(): string {
    return this._description;
  }

  public toString(): string {
    return this._description;
  }
}

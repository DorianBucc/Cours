const nbEtudiants = new Map<string, number>();
nbEtudiants.set("L2", 150);
nbEtudiants.set("L3", 80);
nbEtudiants.set("M1", 60);
nbEtudiants.set("M2", 20);

nbEtudiants.forEach((nb, niveau) => {
    console.log(`${niveau} : ${nb}`);
});

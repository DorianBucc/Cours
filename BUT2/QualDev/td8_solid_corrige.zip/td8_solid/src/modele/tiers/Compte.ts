import { Activite } from "../activites/Activite.ts";
import { FournisseurDonnees } from "./FournisseurDonnees.ts";
import { IRecepteurDonnees } from "./IRecepteurDonnees.ts";
 
export class Compte extends FournisseurDonnees implements IRecepteurDonnees {
    private _nom! : string;
    
    public constructor(id : number, nom : string) {
        super(id);
        this.nom = nom;
    }

    public get nom() : string {
        return this._nom;
    }

    public set nom(nom : string) {
        nom = nom.trim();
        if (nom.length < 2) {
            throw new Error("Le nom doit contenir au moins 2 caractères");
        }
        this._nom = nom;
    }

    public importerActivite(activite : Activite) : void {
        const existe = this.listeActivites.find(a => a.id === activite.id && a.fournisseur.id === activite.fournisseur.id);
        if (existe) {
            throw new Error("L'activité existe déjà");
        }
        this.listeActivites.push(activite);
    }

    public toString() : string {
        return `Compte ${this.nom}`;
    }
}
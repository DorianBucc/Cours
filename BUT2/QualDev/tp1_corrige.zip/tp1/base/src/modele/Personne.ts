export abstract class Personne {
  protected _nom!: string;
  protected _prenom!: string;

  protected constructor(nom: string, prenom: string) {
    this.nom = nom;
    this.prenom = prenom;
  }

  public set nom(nom: string) {
    nom = nom.trim();
    if (nom.length < 1) {
      throw new Error("Le nom doit comporter au moins 1 caractère !");
    }
    this._nom = nom;
  }

  public get nom(): string {
    return this._nom;
  }

  public set prenom(prenom: string) {
    prenom = prenom.trim();
    if (prenom.length < 1) {
      throw new Error("Le prénom doit comporter au moins 1 caractère !");
    }
    this._prenom = prenom;
  }

  public get prenom(): string {
    return this._prenom;
  }

  public toString(): string {
    return this._nom + ", " + this._prenom;
  }
}

import { Enseignant } from "./Enseignant.ts";
import { IEqualize } from "./IEqualize.ts";

export class EnseignantV2 extends Enseignant implements IEqualize {
    public equals(obj: object): boolean {
        if (obj instanceof EnseignantV2) {
            return this.code === obj.code;
        } else {
            return false;
        }
    }
}
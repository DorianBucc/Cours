import ChainePerso from "./ChainePerso.ts";

const ch = new ChainePerso();

ch.saisieClavier();

console.log("Voici la chaîne saisie : ");
ch.affiche();

console.log("Voici la chaîne cryptée : ");
ch.crypte();
ch.affiche();

console.log("Voici la chaîne générée aléatoirement sur 7 caractères : ");
ch.generationAleatoire(7);
ch.affiche();

console.log("Voici la chaîne générée aléatoirement avec 6 voyelles : ");
ch.generationAleatoireVoyelles(6);
ch.affiche();

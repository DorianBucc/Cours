function jazzBundle(n: number): void {
  for (let i = 1; i <= n; i++) {
    if (i % 5 === 0 && i % 3 === 0) {
      console.log("Jazz Bundle");
    } else if (i % 3 === 0) {
      console.log("Jazz");
    } else if (i % 5 === 0) {
      console.log("Bundle");
    } else {
      console.log(i);
    }
  }
}

function jazzBundleAlt(n: number): void {
  for (let i = 1; i <= n; i++) {
    let str = "";
    if (i % 3 === 0 || i % 5 === 0) {
      if (i % 3 === 0) {
        str = "Jazz ";
      }
      if (i % 5 === 0) {
        str += "Bundle";
      }
    } else {
      str = i.toString();
    }
    console.log(str);
  }
}

function saisieEntier(): number {
  const ch = prompt("Veuillez saisir un entier : ");
  if (ch === null) {
    return 0;
  }
  const n = parseInt(ch, 10);
  return n;
}

jazzBundle(saisieEntier());
jazzBundleAlt(saisieEntier());

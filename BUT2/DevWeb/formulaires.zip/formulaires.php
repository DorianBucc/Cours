<?php
  // initialisation des variables à null, utile si reset PHP
  $nom   	= null;
  $prenom	= null;
  $age 		= null;
  $genre	= null;
  $langages	= null;
  $langue 	= null;
  $listeLangages = ["C", "Java", "TypeScript", "PHP", "C++", "Cobol", "Aucun"];
  
  $langues = ['Anglais', 'Allemand', 'Arabe', 'Chinois','Espagnol', 'Portugais'];
  sort($langues);
  // ajout langue par défaut en début de tableau
  array_unshift($langues,'Français');

  if (isset($_POST['valider'])) {
  	$nom      = (isset($_POST['nom'])?strtoupper($_POST['nom']):null);
  	$prenom   = (isset($_POST['prenom'])?$_POST['prenom']:null);
  	$age      = (isset($_POST['age'])?$_POST['age']:null);
  	//  bouton radio
  	$genre    = (isset($_POST['sexe'])?$_POST['sexe']:null);
  	//  checkbox
  	$langages = (isset($_POST['langages'])?$_POST['langages']:null);
  	//  select
  	$langue   = (isset($_POST['langue'])?$_POST['langue']:null);
  }

  include 'formulaires.view.php';
?>

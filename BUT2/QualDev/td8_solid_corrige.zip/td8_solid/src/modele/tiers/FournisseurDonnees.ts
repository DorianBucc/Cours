import { Activite } from "../activites/Activite.ts";
import { IDiffuseurActivites } from "./IDiffuseurActivites.ts";
import { IRecepteurDonnees } from "./IRecepteurDonnees.ts";

export abstract class FournisseurDonnees implements IDiffuseurActivites{
    private _id! : number;
    private _listeComptesLies : IRecepteurDonnees[];
    private _listeActivites : Activite[];

    public constructor(id : number) {
        this.id = id;
        this._listeComptesLies = [];
        this._listeActivites = [];
    }

    public get id() : number {
        return this._id;
    }

    public set id(id : number) {
        this._id = id;
    }

    public get listeComptesLies() : IRecepteurDonnees[] {
        return this._listeComptesLies;
    }

    public ajouterCompteLie(compte : IRecepteurDonnees) : void {
        const existe = this.listeComptesLies.find(c => c.id === compte.id);
        if (existe) {
            throw new Error("Le compte est déjà lié");
        }
        this.listeComptesLies.push(compte);
    }

    public supprimerCompteLie(compte : IRecepteurDonnees) : void {
        const index = this.listeComptesLies.findIndex(c => c.id === compte.id);
        if (index === -1) {
            throw new Error("Le compte n'est pas lié");
        }
        this.listeComptesLies.splice(index, 1);
    }

    public get listeActivites() : Activite[] {
        return this._listeActivites;
    }

    public ajouterActivite(activite : Activite) : void {
        if (activite.fournisseur.id !== this.id) {
            throw new Error("L'activité ne correspond pas au compte");
        }
        const index = this.listeActivites.findIndex(a => a.id === activite.id && activite.fournisseur.id === this.id);
        if (index !== -1) {
            throw new Error("L'activité existe déjà");
        }
        this.listeActivites.push(activite);
        this.diffuserActivite(activite);
    }

    public supprimerActivite(activite : Activite) : void {
        const index = this.listeActivites.findIndex(a => a.id === activite.id && a.fournisseur.id === activite.fournisseur.id);
        if (index === -1) {
            throw new Error("L'activité n'existe pas");
        }
        this.listeActivites.splice(index, 1);
    }


    public abstract toString() : string;

    public diffuserActivite(activite: Activite): void {
        for( const cpt of this._listeComptesLies) {
          cpt.importerActivite(activite);
        }
    }  
}
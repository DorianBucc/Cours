import { Figure } from "./Figure.ts";

export class Rectangle extends Figure {

    private _longueur! : number;
    private _largeur! : number;

    constructor(x:number, y:number,longueur: number, largeur: number) {
      super(x, y);
      this.longueur = longueur;
      this.largeur = largeur;
    }
    public get longueur(): number {
      return this._longueur;
    }   
    public set longueur(longueur: number) {
      this._longueur = longueur;
    }   
    public get largeur(): number {
      return this._largeur;
    }
    public set largeur(largeur: number) {
      this._largeur = largeur;
    }   

    public getAire(): number {
      return this._longueur*this._largeur;
    }   
} 
import { IObserver } from "./IObserver.ts";
import { Observable } from "./Observable.ts";
import { plot } from "https://deno.land/x/chart@1.1/mod.ts";

export class AfficheurAsciiChart implements IObserver {

    private tabTemperature: Array<number>;
    private tabHumidite: Array<number>;
    
    constructor() {
        this.tabTemperature=[];
        this.tabHumidite=[];
    }

    notify(o : Observable) : void {
        
        const valeurs = o.toString().split("\n").map(e => parseFloat(e));
        this.tabTemperature.push(valeurs[0]);
        this.tabHumidite.push(valeurs[1])
        console.log(plot([this.tabTemperature, this.tabHumidite]));
    }
    
 
}
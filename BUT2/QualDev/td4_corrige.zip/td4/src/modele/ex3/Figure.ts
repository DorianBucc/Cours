import { ICalculateurAire } from "./ICalculateurAire.ts";

export abstract class Figure implements ICalculateurAire {
  private _x!: number;
  private _y!: number;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
  }

  public get x(): number {
    return this._x;
  }

  public set x(x: number) {
    this._x = x;
  }

  public get y(): number {
    return this._y;
  }

  public set y(y: number) {
    this._y = y;
  }

  public abstract getAire(): number;
}

export abstract class BanditManchot {
  private _nbCylindres!: number;
  private _symboles!: number[];
  protected _misesPossibles!: number[];
  protected _resultats: number[];

  protected constructor(
    nbCylindres: number,
    symboles: number[],
    misesPossibles: number[],
  ) {
    this.nbCylindres = nbCylindres;
    this.symboles = symboles;
    this.misesPossibles = misesPossibles;
    this._resultats = [];
  }

  public set nbCylindres(nbCylindres: number) {
    if (nbCylindres < 3 || nbCylindres > 5) {
      throw Error("Le nombre de cylindres doit être compris entre 3 et 5 !");
    }
    this._nbCylindres = nbCylindres;
  }

  public set symboles(symboles: number[]) {
    if (symboles.length < 3 || symboles.length > 7) {
      throw Error("Le nombre de symboles doit être compris entre 3 et 7 !");
    }
    if (symboles.some((symbole) => symbole < 1 || symbole > 9)) {
      throw Error("Les symboles doivent être compris entre 1 et 9 !");
    }
    if (symboles.some((symbole) => !Number.isInteger(symbole))) {
      throw Error("Les symboles doivent être des entiers !");
    }
    this._symboles = symboles;
  }

  public get symboles(): number[] {
    return this._symboles;
  }
  public set misesPossibles(misesPossibles: number[]) {
    if (misesPossibles.length < 1) {
      throw Error("Il faut au moins une mise possible !");
    }
    if (misesPossibles.some((mise) => mise < 0)) {
      throw Error("Les mises ne peuvent pas être négatives !");
    }
    this._misesPossibles = misesPossibles;
  }

  public get misesPossibles(): number[] {
    return this._misesPossibles;
  }

  protected lance(mise: number): number[] {
    if (!this._misesPossibles.includes(mise)) {
      throw Error("La mise n'est pas possible !");
    }
    const res: number[] = [];
    for (let i = 0; i < this._nbCylindres; i++) {
      res.push(
        this._symboles[Math.floor(Math.random() * this._symboles.length)],
      );
    }
    this._resultats = res;
    return res;
  }

  public abstract getResultatLancement(mise: number): number[];
}

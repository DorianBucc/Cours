import { MonSingleton } from "./MonSingleton.ts";

console.log("Création de s1 vide");

const s1 = MonSingleton.getInstance();

console.log("s1 : " + s1.toString());


console.log("Création de s2 avec texte s2");

const s2 = MonSingleton.getInstance("s2");

console.log("s1 : " + s1.toString());
console.log("s2 : " + s2.toString());

console.log("Modification de s1 avec texte s1");
s1.texte = "s1";
console.log("s1 : " + s1.toString());
console.log("s2 : " + s2.toString());




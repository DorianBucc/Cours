<?php
    require_once 'connexion.php'; 
    require_once 'equipement.class.php';

class EquipementDAO{

    private $bd;
    private $select;

    function __construct(){
        $this->bd = new Connexion();
        $this->select = 'SELECT id_equipt, lib_equipt, commentaire FROM `TYPE_EQUIPT` ';
    }

    function insert (Equipement $equipement) : void {
        $this->bd->execSQL("INSERT INTO TYPE_EQUIPT (id_equipt, lib_equipt, commentaire)
                            VALUES (NULL, :libelle, :commentaire)"
                            ,[':libelle'=>$equipement->getLibelle() ,':commentaire'=>$equipement->getCommentaire() ] );
    }    

    function delete (string $idEquipt) : void {
        $this->bd->execSQL("DELETE FROM TYPE_EQUIPT 
                            WHERE id_equipt = :idEquipt", [':idEquipt'=>$idEquipt ]);
    } 

    function update (Equipement $equipement) : void {
        $this->bd->execSQL("UPDATE TYPE_EQUIPT 
                            SET lib_equipt = :libelle, commentaire = :commentaire
                            WHERE id_equipt = :id"
                            ,[':id'=>$equipement->getId(), ':libelle'=>$equipement->getLibelle() ,':etage'=>$equipement->getCommentaire() ] );
    }    

    private function loadQuery (array $result) : array { 
        $equipements = [];
        foreach($result as $row) {
            $equipement = new Equipement(); 
            $equipement->setId($row['id_equipt']); 
            $equipement->setLibelle($row['lib_equipt']); 
            $equipement->setCommentaire($row['commentaire']); 
            $equipements[] = $equipement;
        }
        return $equipements;
    }

    function getAll () : array {
        return ($this->loadQuery($this->bd->execSQLselect($this->select)));
    }

    function getById (string $id) : Equipement {
        $unEquipement = new Equipement();
        $lesEquipements = $this->loadQuery($this->bd->execSQLselect($this->select ." WHERE
        id_equipt=:id", [':id'=>$id]) );
        if (count($lesEquipements)>0) { 
            $unEquipement = $lesEquipements[0]; 
        }
        return $unEquipement;
        // il y a un seul élément dans le tableau de salles ➔ indice 0 return $unEquipement;
    }	

    function existe (string $id) : bool {
        $req = "SELECT * 
                FROM TYPE_EQUIPT 
                WHERE id_equipt = :id";
        $res = ($this->loadQuery($this->bd->execSQLselect($req,[':id'=>$id])));
        return ($res != []); // si tableau de salles est vide alors l'équipement' n’existe pas
    }


    function getNonInventaire (string $numSalle) : array {
        // retourne le tableau des types d’équipement non présents dans la salle $numSalle. 
        return ($this->loadQuery($this->bd->execSQLselect($this->select ."
                                    WHERE id_equipt NOT IN 
                                        (SELECT id_equipt
                                        FROM CONTIENT
                                        WHERE num_salle=:num)"
                                    , [':num'=>$numSalle])));
    }
}    

?>
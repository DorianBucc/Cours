import { Auteur } from "../modele/Auteur.ts";
import { Role } from "../modele/Role.ts";

export class Utils {
  public static auteursToString(
    auteurs: Map<Auteur, Array<Role | null>>,
  ): string {
    let ch = "";
    for (const auteur of auteurs.keys()) {
      ch += auteur.toString() + " : ";
      let unRole = false;
      for (const role of auteurs.get(auteur)!) {
        if (role != null && role != undefined) {
          unRole = true;
          ch += role.toString() + ", ";
        }
      }
      // Si aucun rôle n'est indiqué, on supprime " : " à la fin de la chaîne "<Auteur> : "
      if (!unRole) {
        ch = ch.substring(0, ch.length - 3) + " ; ";
      } else {
        ch = ch.substring(0, ch.length - 2) + " ; ";
      }
    }
    return ch;
  }
}

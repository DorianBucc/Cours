export class Departement {

    private _nom! : string;

    public constructor(nom: string) {
        this.nom = nom;
    }

    public set nom(nom: string) {
        nom = nom.trim().toUpperCase();
        if (nom.length < 2) {
            throw new Error("Le nom du département doit contenir au moins 2 caractères");
        }
        this._nom = nom;
    }

    public get nom(): string {
        return this._nom;
    }

    public toString(): string {
        return this._nom;
    }

}
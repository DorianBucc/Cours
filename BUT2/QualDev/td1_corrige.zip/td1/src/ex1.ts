/*
paramètre msg (message à afficher) avec valeur par défaut vide
cela permet :
1) d'appeler la fonction sans paramètre, cela affiche un message par défaut
ou
2) d'appeler la fonction avec un message spécifique
*/

/* V0.1 : pas de type de retour : pas bien ! */
function q1LitChainePasPropre1() {
  return prompt("Saisir une chaîne");
}

/* V0.2 : type de retour conforme à prompt mais dangeureux : pas assez typé ! */
function q1LitChainePasPropre2(): string | null {
  return prompt("Saisir une chaîne");
}

/* V0.3 : terrorisme intellectuel */
/* ! c'est pour dire au compilateur "je suis sûr que c'est pas null"...
/* ... mais en fait je suis pas sûr du tout ! */
function q1LitChainePasPropre3(): string {
  return prompt("Saisir une chaîne")!;
}

function q1LitChaine(msg = ""): string {
  let ch: string | null;
  do {
    ch = prompt(msg === "" ? "Veuillez saisir une chaîne quelconque : " : msg);
  } while (ch === null);
  return ch;
}

// En utilisant do {...}while, on rentre toujours au moins 1x dans la boucle
// et cela permet de n'appeler q1LitChaine qu'une seule fois !
function q2LitChaineMajuscules(): string {
  let ch: string;
  do {
    ch = q1LitChaine("Veuillez saisir une chaîne en majuscules : ");
  } while (ch.toUpperCase() !== ch);
  return ch;
  // remarque : si "let ch" est déplacé dans la boucle (ligne 21)
  // ch devient locale au bloc "do {...} while" est n'est plus connue dans la condition "while (...)"
}

console.log("la chaîne saisie est : " + q1LitChaine("Quel est ton nom ?"));
console.log("la chaîne saisie est : " + q2LitChaineMajuscules());

import { Triple } from "../modele/ex1_4/Triple.ts";
import { TripleList } from "../modele/ex1_4/TripleList.ts"
import { Stack } from "../modele/ex2/Stack.ts";
import { Figure } from "../modele/ex3/Figure.ts";
import { FigurePair } from "../modele/ex3/FigurePair.ts";
import { ICalculateurAire } from "../modele/ex3/ICalculateurAire.ts";
import { Rectangle } from "../modele/ex3/Rectangle.ts";
import { Triangle } from "../modele/ex3/Triangle.ts";

console.log("Exercice 1 : Triplets");

const t1 = new Triple<string, number, boolean>("test", 14, true);
console.log(t1.toString());

const t2 = new Triple<number, number, number>(65, 41, 21);
console.log(t2.toString());

const t3 = new Triple<string, string, string>("A", "B", "C");
console.log(t3.toString());

console.log("Liste de triplets");
const lt = new TripleList<string, number, number>();
lt.add(new Triple<string, number, number>("euros", 100, 1));
lt.add(new Triple<string, number, number>("dollars", 4000, 0.85));
lt.add(new Triple<string, number, number>("yens", 14000, 0.002));

let somme=0;
lt.forEach(elt=>somme+=elt.second*elt.third);
console.log("Somme en euros : " + somme);

console.log("Exercice 2 : Pile entier");

const pile1 = new Stack<number>();
console.log(pile1.size(), pile1.isEmpty());
console.log("push");
pile1.push(40);
console.log(pile1.size(), pile1.isEmpty());
console.log("Dernier élément : " + pile1.peek());
console.log(pile1.size(), pile1.isEmpty());
console.log("pop", pile1.pop());
console.log(pile1.size(), pile1.isEmpty());
try {
  console.log("encore un pop");
  let last = pile1.pop();
} catch (error) {
  if (error instanceof Error) {
    console.log(error.message);
  }
}

console.log("Pile chaînes");

const pile2 = new Stack<string>();
console.log(pile2.size(), pile2.isEmpty());
console.log("push");
pile2.push("hello");
console.log(pile2.size(), pile2.isEmpty());
console.log("push");
pile2.push("world");
console.log(pile2.size(), pile2.isEmpty());
console.log("Dernier élément : " + pile2.peek());
console.log(pile2.size(), pile2.isEmpty());
console.log("pop", pile2.pop());
console.log(pile2.size(), pile2.isEmpty());
console.log("pop", pile2.pop());
console.log(pile2.size(), pile2.isEmpty());

console.log("Exercice 3 Figures");
const f1 = new FigurePair<Figure>(new Triangle(0, 0, 12, 5.3), new Rectangle(-1, 7, 3, 2));
console.log(f1.aireTotale());

const f2 = new FigurePair<ICalculateurAire>(new Triangle(0, 0, 12, 5.3), new Rectangle(-1, 7, 3, 2));
console.log(f2.aireTotale());

// a noter : si Triangle n'implements pas l'interface mais contient une méthode
// nommée comme dans l'interface, ça passe !

console.log("Exercice 4");
const cumul = lt.reduce((acc, elt)=>new Triple<string, number, number>("euros", acc.second+elt.second*elt.third, 1), new Triple<string, number, number>("euros", 0, 1));
console.log("Somme en euros (2) : " + cumul.second);


import { BanditManchot } from "./BanditManchot.ts";

export class BanditManchotType2 extends BanditManchot {
  public constructor() {
    super(5, [2, 3, 4, 5, 6, 7, 8], [0.1, 0.2, 0.5]);
  }

  public getResultatLancement(mise: number): number[] {
    if (!this._misesPossibles.includes(mise)) {
      throw Error("La mise n'est pas possible !");
    }
    this.lance(mise);
    const groupes = new Map<number, number>();

    this._resultats.forEach((resultat) => {
      if (groupes.has(resultat)) {
        groupes.set(resultat, groupes.get(resultat)! + 1);
      } else {
        groupes.set(resultat, 1);
      }
    });

    let gain = 0;
    for (const [symbole, nb] of groupes) {
      if (nb >= 3) {
        gain = symbole * nb * mise;
        break;
      }
    }

    return [...this._resultats, gain];
  }
}

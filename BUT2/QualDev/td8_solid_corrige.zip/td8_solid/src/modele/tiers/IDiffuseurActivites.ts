import { Activite } from "../activites/Activite.ts";

export interface IDiffuseurActivites {
    diffuserActivite(activite: Activite): void;
}

import { FournisseurDonnees } from "./tiers/FournisseurDonnees.ts";

export class Sportif {
    private _id! : number;
    private _nom! : string;
    private _prenom! : string;
    private _dateDeNaissance! : Date;
    private _sexe! : string;
    private _taille! : number;
    private _poids! : number;
    private _listeComptes : FournisseurDonnees[];

    public constructor(id : number, nom : string, prenom : string, dateDeNaissance : Date, sexe : string, taille : number, poids : number) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.dateDeNaissance = dateDeNaissance;
        this.sexe = sexe;
        this.taille = taille;
        this.poids = poids;
        this._listeComptes = [];
    }

    public get id() : number {
        return this._id;
    }

    public set id(id : number) {
        this._id = id;
    }

    public get nom() : string {
        return this._nom;
    }

    public set nom(nom : string) {
        nom = nom.trim();
        if (nom.length < 2) {
            throw new Error("Le nom doit contenir au moins 2 caractères");
        }
        this._nom = nom;
    }

    public get prenom() : string {
        return this._prenom;
    }

    public set prenom(prenom : string) {
        prenom = prenom.trim();
        if (prenom.length < 2) {
            throw new Error("Le prénom doit contenir au moins 2 caractères");
        }
        this._prenom = prenom;
    }

    public get dateDeNaissance() : Date {
        return this._dateDeNaissance;
    }

    public set dateDeNaissance(dateDeNaissance : Date) {
        this._dateDeNaissance = dateDeNaissance;
    }

    public get sexe() : string {
        return this._sexe;
    }

    public set sexe(sexe : string) {
        if (sexe !== 'M' && sexe !== 'F') {
            throw new Error("Le sexe doit être M ou F");
        }
        this._sexe = sexe;
    }

    public get taille() : number {
        return this._taille;
    }

    public set taille(taille : number) {
        if (taille < 0) {
            throw new Error("La taille doit être positive");
        }
        this._taille = taille;
    }

    public get poids() : number {
        return this._poids;
    }

    public set poids(poids : number) {
        if (poids < 0) {
            throw new Error("Le poids doit être positif");
        }
        this._poids = poids;
    }

    public get listeComptes() : FournisseurDonnees[] {
        return this._listeComptes;
    }

    public ajouterFournisseurDonnees(compte : FournisseurDonnees) : void {
        const existe = this._listeComptes.find(c => c.id === compte.id);
        if (existe) {
            throw new Error("Le compte existe déjà");
        }
        this._listeComptes.push(compte);
    }

    public supprimerFournisseurDonnees(compte : FournisseurDonnees) : void {
        this._listeComptes = this._listeComptes.filter(c => c.id !== compte.id);
    }

    public toString() : string {
        return `${this.nom} ${this.prenom} (${this.dateDeNaissance.toLocaleDateString()})`;
    }
}
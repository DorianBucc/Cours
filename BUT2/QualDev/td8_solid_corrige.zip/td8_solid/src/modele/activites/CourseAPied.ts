import { FournisseurDonnees } from "../tiers/FournisseurDonnees.ts";
import { Activite } from "./Activite.ts";

export class CourseAPied extends Activite {

    private _distance! : number;
    private _cadence! : number;

    public constructor(id : number, dateHeure : Date, duree : number, bpmMoyen : number, distance : number, cadence : number, compte : FournisseurDonnees) {
        super(id, dateHeure, duree, bpmMoyen, compte);
        this.distance = distance;
        this.cadence = cadence;
    }

    public get distance() : number {
        return this._distance;
    }

    public set distance(distance : number) {
        if (distance <= 0) {
            throw new Error("La distance doit être positive");
        }
        this._distance = distance;
    }

    public get cadence() : number {
        return this._cadence;
    }

    public set cadence(cadence : number) {
        if (cadence <= 0) {
            throw new Error("La cadence doit être positive");
        }
        this._cadence = cadence;
    }

    public get type() : string {
        return "Course à pied";
    }

    public toString() : string {
        return `${super.toString()} : ${this.distance} km à ${this.cadence} pas/min`;
    }
}
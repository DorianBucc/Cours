// Question 5.2) de l'exercice 1
export function inverse(elt: string, idx:number, tab : Array<string>):void {
    if (idx < tab.length / 2) {
        const tmp = tab[tab.length - 1 - idx];
        tab[idx] = tmp;
        tab[tab.length - 1 - idx] = elt;
    }
}

// Question 5.4) de l'exercice 1
export const inverse_2 = (elt: string, idx:number, tab : Array<string>):void => {
    if (idx < tab.length / 2) {
        const tmp = tab[tab.length - 1 - idx];
        tab[idx] = tmp;
        tab[tab.length - 1 - idx] = elt;
    }
};
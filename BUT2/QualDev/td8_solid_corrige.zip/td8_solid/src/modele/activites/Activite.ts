import { FournisseurDonnees } from "../tiers/FournisseurDonnees.ts";

export abstract class Activite {

    private _id! : number;
    private _dateHeure! : Date;
    private _duree! : number;
    private _bpmMoyen! : number;
    private _fournisseur! : FournisseurDonnees;

    public constructor(id : number, dateHeure : Date, duree : number, bpmMoyen : number, fournisseur : FournisseurDonnees) {
        this.id = id;
        this.dateHeure = dateHeure;
        this.duree = duree;
        this.bpmMoyen = bpmMoyen;
        this.fournisseur = fournisseur;
    }

    public get id() : number {
        return this._id;
    }

    public set id(id : number) {
        this._id = id;
    }

    public get dateHeure() : Date {
        return this._dateHeure;
    }   

    public set dateHeure(dateHeure : Date) {
        this._dateHeure = dateHeure;
    }

    public get duree() : number {
        return this._duree;
    }

    public set duree(duree : number) {
        if (duree <= 0) {
            throw new Error("La durée doit être positive");
        }
        this._duree = duree;
    }
    
    public get bpmMoyen() : number {
        return this._bpmMoyen;
    }

    public set bpmMoyen(bpmMoyen : number) {
        if (bpmMoyen <= 0) {
            throw new Error("Le BPM moyen doit être positif");
        }
        this._bpmMoyen = bpmMoyen;
    }

    public get fournisseur() : FournisseurDonnees {
        return this._fournisseur;
    }

    public set fournisseur(fournisseur : FournisseurDonnees) {
        this._fournisseur = fournisseur;
    }

    public abstract get type() : string;

    public toString() : string {
        return `Activité ${this.type} du ${this.dateHeure.toLocaleDateString()} à ${this.dateHeure.toLocaleTimeString()} (${this.duree} minutes)`;
    }
}
import { Activite } from "../activites/Activite.ts";

export interface IRecepteurDonnees {
    importerActivite(activite: Activite): void;
    
    get id(): number;
}
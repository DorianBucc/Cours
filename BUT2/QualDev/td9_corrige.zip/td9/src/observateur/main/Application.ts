import { StationMeteo } from "../modele/StationMeteo.ts";
import { AfficheurTexte } from "../modele/AfficheurTexte.ts";
import { AfficheurAsciiChart } from "../modele/AfficheurAsciiChart.ts";

const aff = new AfficheurTexte();
const aff2 = new AfficheurAsciiChart();
const s = new StationMeteo(10)

s.ajouteObservateur(aff);
s.ajouteObservateur(aff2);

do {
    console.log("Appuyez sur entrée pour le prochain affichage");
    prompt("");

    let diffHumidite = Math.floor(Math.random() * 3);
    const plusMoinsHumidite = Math.floor(Math.random() * 2);
    if (plusMoinsHumidite == 0) {
        diffHumidite=-diffHumidite;
    }
    s.humidite = s.humidite + diffHumidite;

    let diffTemperature = Math.floor(Math.random() * 3);
    const plusMoinsTemperature = Math.floor(Math.random() * 2);
    if (plusMoinsTemperature == 0) {
        diffTemperature=-diffTemperature;
    }
    s.temperature = s.temperature + diffTemperature;    
} while (true);

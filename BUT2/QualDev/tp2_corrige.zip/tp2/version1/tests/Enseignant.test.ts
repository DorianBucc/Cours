import { Enseignant } from "../src/modele/Enseignant.ts";
import { Departement } from "../src/modele/Departement.ts";
import { assertEquals, assertThrows } from "https://deno.land/std@0.201.0/assert/mod.ts";

function setUp(): Enseignant {
  const enseignant = new Enseignant("Zsuzsanna", "Roka");
  return enseignant;
}

Deno.test("Volume horaire vide à la création", () => {
  const enseignant = setUp();
  assertEquals(enseignant.volumeHoraire.size, 0);
});

Deno.test("Ajout volume horaire département inexistant", () => {
  const enseignant = setUp();
  const dpt = new Departement("INFO");
  
  enseignant.ajouteVolumeHoraire(dpt, 10);
  assertEquals(enseignant.volumeHoraire.size, 1);
  assertEquals(enseignant.volumeHoraire.keys().next().value, dpt);
  assertEquals(enseignant.volumeHoraire.get(dpt), 10);
});

Deno.test("Ajout volume horaire 2nd département inexistant", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    const dpt2 = new Departement("GMP");
    
    enseignant.ajouteVolumeHoraire(dpt1, 10);
    enseignant.ajouteVolumeHoraire(dpt2, 20);
    assertEquals(enseignant.volumeHoraire.size, 2);
    assertEquals(enseignant.volumeHoraire.get(dpt1), 10);
    assertEquals(enseignant.volumeHoraire.get(dpt2), 20);
  });

  Deno.test("Ajout volume horaire département existant", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    
    enseignant.ajouteVolumeHoraire(dpt1, 10);
    enseignant.ajouteVolumeHoraire(dpt1, 20);
    assertEquals(enseignant.volumeHoraire.size, 1);
    assertEquals(enseignant.volumeHoraire.get(dpt1), 30);
  });

  Deno.test("Retrait volume horaire département existant avec reste", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    
    enseignant.ajouteVolumeHoraire(dpt1, 10);
    enseignant.retireVolumeHoraire(dpt1, 8);
    assertEquals(enseignant.volumeHoraire.size, 1);
    assertEquals(enseignant.volumeHoraire.get(dpt1), 2);
  });

  Deno.test("Retrait volume horaire département existant sans reste", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    
    enseignant.ajouteVolumeHoraire(dpt1, 10);
    enseignant.retireVolumeHoraire(dpt1, 10);
    assertEquals(enseignant.volumeHoraire.size, 0);
  });

  Deno.test("Retrait volume horaire département existant, trop important", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    
    enseignant.ajouteVolumeHoraire(dpt1, 10);
    assertThrows(()=> enseignant.retireVolumeHoraire(dpt1, 11));
  });

  Deno.test("Retrait volume horaire département inexistant", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    
    assertThrows(()=> enseignant.retireVolumeHoraire(dpt1, 10));
  });

  Deno.test("volumeHoraireToString vide", () => {
    const enseignant = setUp();
    assertEquals(enseignant.volumeHoraireToString(), "");
  });

  Deno.test("volumeHoraireToString non vide", () => {
    const enseignant = setUp();
    const dpt1 = new Departement("INFO");
    const dpt2 = new Departement("GMP");
    
    enseignant.ajouteVolumeHoraire(dpt1, 10);
    enseignant.ajouteVolumeHoraire(dpt2, 20);
    assertEquals(enseignant.volumeHoraireToString(), "INFO : 10\nGMP : 20\n");
  });


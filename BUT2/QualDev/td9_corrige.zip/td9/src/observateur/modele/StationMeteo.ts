import { Observable } from "./Observable.ts";

export class StationMeteo extends Observable {

    private _temperature! : number;
    private _humidite! : number;

    constructor(temperature = 0, humidite = 15) {
        super();
        this.temperature = temperature;
        this.humidite = humidite;
    }

    public get temperature(): number {
        return this._temperature;
    }

    public set temperature(temperature: number) {
        this._temperature = temperature;
        this.notifyObservers();
    }

    public get humidite(): number {
        return this._humidite;
    }

    public set humidite(humidite: number) {
        
        if (humidite < 0 || humidite > 100) {
            throw new Error("L'humidité est exprimée en pourcentage !");
        }
        this._humidite = humidite;
        this.notifyObservers();
    }

    public toString() : string {

        return this._temperature + "°C\n" + 
                this._humidite + "%";
    }

}
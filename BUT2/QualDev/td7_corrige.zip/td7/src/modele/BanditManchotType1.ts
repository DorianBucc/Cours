import { BanditManchot } from "./BanditManchot.ts";

export class BanditManchotType1 extends BanditManchot {
  private _tableauGains!: Array<Array<number>>;

  public constructor() {
    super(3, [1, 2, 3, 4, 5], [1, 2]);
    this.setCombinaisonsGagnantes();
  }

  private setCombinaisonsGagnantes(): void {
    this._tableauGains = [];
    for (const s of this.symboles) {
      this._tableauGains.push([s, 2, s * 2]);
    }
    for (let s = 3; s <= 5; s++) {
      this._tableauGains.push([s, 3, s * 20]);
    }
  }

  public getResultatLancement(mise: number): number[] {
    if (!this._misesPossibles.includes(mise)) {
      throw Error("La mise n'est pas possible !");
    }
    this.lance(mise);
    const groupes = new Map<number, number>();
    this._resultats.forEach((resultat) => {
      if (groupes.has(resultat)) {
        groupes.set(resultat, groupes.get(resultat)! + 1);
      } else {
        groupes.set(resultat, 1);
      }
    });

    let gain = 0;
    for (let i = this._tableauGains.length - 1; i >= 0; i--) {
      const combinaison = this._tableauGains[i];
      if (
        groupes.has(combinaison[0]) &&
        groupes.get(combinaison[0])! >= combinaison[1]
      ) {
        gain = combinaison[2] * mise;
        break;
      }
    }

    return [...this._resultats, gain];
  }
}

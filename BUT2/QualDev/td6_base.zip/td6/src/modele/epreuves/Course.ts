import { Epreuve } from "./Epreuve.ts";
import { TypeEpreuve } from "./TypeEpreuve.ts";

export class Course extends Epreuve {
  constructor(nom: string) {
    super(nom, "secondes", TypeEpreuve.Course);
  }
}

<?php
class Salle {
    
    private $numSalle;
    private $libSalle;
    private $etage;

    // constructeur    
    function __construct(string $num='', string $libelle='', string $etage=''){
        $this->numSalle = $num;
        $this->libSalle = $libelle;
        $this->etage = $etage;
    }

    // getters
    function getNum():string{
        return $this->numSalle;
    }
    
    function getLibelle():string|null{
        return $this->libSalle;
    }

    function getEtage():string{
        return $this->etage;
    }

    // setters    
    function setNum(string $num):void{
        $this->numSalle = $num;
    }
    function setLibelle(string|null $libelle):void{
        $this->libSalle = $libelle;
    }
    function setEtage(string $etage):void{
        $this->etage = $etage;
    }


}

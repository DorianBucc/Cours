import { Auteur } from "./Auteur.ts";
import { Role } from "./Role.ts";
import { Document } from "./Document.ts";

export class CD extends Document {
  private _styles!: Array<string>;

  constructor(
    titre: string,
    auteurs: Map<Auteur, Array<Role | null>>,
    editeur: string,
    styles: Array<string>,
  ) {
    super(titre, auteurs, editeur);
    this.styles = styles;
  }

  public set styles(styles: Array<string>) {
    if (styles.length == 0) {
      throw new Error("Un cd doit avoir un ou plusieurs styles.");
    }
    for (let unStyle of styles) {
      unStyle = unStyle.trim();
    }
    if (styles.includes("")) {
      throw new Error("un des styles est vide !");
    }
    this._styles = styles;
  }

  public get styles(): Array<string> {
    return this._styles;
  }
  public toString(): string {
    return "CD " + super.toString() + "\n\tStyles : " +
      this._styles.toString().replaceAll(",", ", ");
  }
}

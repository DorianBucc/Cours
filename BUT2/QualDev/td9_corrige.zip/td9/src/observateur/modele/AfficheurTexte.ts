import { IObserver } from "./IObserver.ts";
import { Observable } from "./Observable.ts";


export class AfficheurTexte implements IObserver {

    notify(o : Observable) : void {
        console.log(o.toString());
    }   
}
import { Figure } from "./Figure.ts";

export class Triangle extends Figure {

  private _base!: number;
  private _hauteur!: number;

  constructor(x:number, y:number,base: number, hauteur: number) {
    super(x, y);
    this.base = base;
    this.hauteur = hauteur;
  }
  public get base(): number {
    return this._base;
  }
  public set base(base: number) {
    this._base = base;
  }
  public get hauteur(): number {
    return this._hauteur;
  }
  public set hauteur(hauteur: number) {
    this._hauteur = hauteur;
  }

  public getAire(): number {
    return this._base*this._hauteur/2;
  }
}

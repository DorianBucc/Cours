import { Decathlon } from "../modele/Decathlon.ts";
import { Menu } from "../controleur/Menu.ts";
import { FileAthleteDAO } from "../dao/FileAthleteDAO.ts";
import { FileEpreuveDAO } from "../dao/FileEpreuveDAO.ts";
import { FileResultatDAO } from "../dao/FileResultatDAO.ts";

const competition = new Decathlon(
  "Décastar Talence",
  new Date(2022, 8, 17),
  new Date(2022, 8, 18),
);

FileEpreuveDAO.completeEpreuvesCompetition(
  "decathlon",
  competition.getEpreuves(),
);

const dossier = "talence2022";

competition.athletes = await FileAthleteDAO.chargeAthletes(dossier);

competition.resultats = await FileResultatDAO.chargeResultats(
  dossier,
  competition.athletes,
  competition.getEpreuves(),
);

Menu.gestionCompetition(competition);

FileResultatDAO.sauveResultats(dossier, competition.resultats);

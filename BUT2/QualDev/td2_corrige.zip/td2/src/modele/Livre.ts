import { Document } from "./Document.ts";
import { Auteur } from "./Auteur.ts";
import { Role } from "./Role.ts";

export class Livre extends Document {
  private _collection!: string;

  constructor(
    titre: string,
    auteurs: Map<Auteur, Array<Role | null>>,
    editeur: string,
    collection: string,
  ) {
    super(titre, auteurs, editeur);
    this.collection = collection;
  }

  public set collection(collection: string) {
    collection = collection.trim();
    if (collection.length < 2) {
      throw new Error("La collection doit comporter au moins 2 caractère !");
    }
    this._collection = collection;
  }

  public get collection(): string {
    return this._collection;
  }

  public toString(): string {
    let ch = super.toString();

    const idx = ch.indexOf(")");
    ch = ch.substring(0, idx) + ", collection : " + this._collection +
      ch.substring(idx);
    return `Livre ${ch}`;
  }
}

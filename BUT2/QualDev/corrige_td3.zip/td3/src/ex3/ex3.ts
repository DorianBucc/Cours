import { Monnaie } from "./Monnaie.ts";

const m1=new Monnaie("Euros", 100, 100);
const m2=new Monnaie("Dollars", 10, 8.5);
const m3=new Monnaie("Yens", 100000, 750);
const m4=new Monnaie("Francs", 10000, 0.5);

const affiche = (tab:Array<Monnaie>):void => tab.forEach(elt => console.log(elt.toString()));

const tab = [m1, m2, m3, m4];

// 1)
console.log("1.");
tab.forEach(elt => console.log(elt.toString()));

// 2)
console.log("2.");
const tab100 = tab.filter(elt => elt.valeurEnEuros > 100);
affiche(tab100);

// 3)
console.log("3.");
tab.map(elt => elt.nom).forEach(elt=>console.log(elt));

// 4)
console.log("4. Au moins une en euros supérieure à 1000 : " + tab.some(elt => elt.valeurEnEuros > 1000));

// 5)
console.log("5. Toutes positives ? " + tab.every(elt => elt.valeurEnEuros >= 0));

//6)
console.log("6.");
affiche(tab.map(elt => new Monnaie(elt.nom.toUpperCase(), elt.valeur, elt.valeurEnEuros)));

// 7)
console.log("7.");
tab.sort((m1, m2)=> m1.valeurEnEuros - m2.valeurEnEuros);
affiche(tab);

// 8)
console.log("8.");
tab.sort((m1, m2)=> m1.nom.localeCompare(m2.nom));
affiche(tab);

// 9) v1
let cumul = 0;
tab.forEach(elt=>cumul+=elt.valeurEnEuros);
console.log("9v1. Cumul : " + cumul);

// 9) v2
console.log("9v2. Cumul 2 : " + tab.reduce((cumul, elt) => cumul + elt.valeurEnEuros, 0));

// 10)
console.log("10. Max : " + tab.reduce((max, elt) => max > elt.valeurEnEuros ? max : elt.valeurEnEuros, Number.MIN_VALUE));

// 11)
console.log("11. Min : " + tab.reduce((min, elt) => min < elt.valeurEnEuros ? min : elt.valeurEnEuros, Number.MAX_VALUE));

// 12) A éviter, inneficace !
console.log("12. Max v1 : " + tab.find(m => 
            m.valeurEnEuros === tab.reduce((max, elt) => max > elt.valeurEnEuros ? max : elt.valeurEnEuros, Number.MIN_VALUE)
            )!.nom);
// 12) OK
const max = tab.reduce((max, elt) => max > elt.valeurEnEuros ? max : elt.valeurEnEuros, Number.MIN_VALUE);
console.log("12. Max v2 : " + tab.find(m => m.valeurEnEuros === max)!.nom);

// 13)
console.log("13.");
tab.filter(elt=>elt.valeur > 10).map(elt => elt.nom).forEach(elt=>console.log(elt));

// 14)
console.log("14.");
tab.map(elt => [elt.valeur, elt.valeurEnEuros]).forEach(elt=>console.log(elt));


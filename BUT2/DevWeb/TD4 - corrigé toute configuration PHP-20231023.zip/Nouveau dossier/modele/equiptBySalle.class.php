<?php
    require_once 'equipement.class.php';

class EquiptBySalle {
    // table CONTIENT

    private $numSalle;
    private $equipement; 
    private $qte;

    function __construct(string $numSalle='', Equipement $equipement=null, int $qte=0){
        $this->numSalle = $numSalle;
        $this->equipement = $equipement;
        $this->qte = $qte;
    }

     // getters
    function getNumSalle():string{
        return $this->numSalle;
    }
    function getEquipement():Equipement{
        return $this->equipement;
    }
    function getQte():int{
        return $this->qte;
    }

    // setters    
    function setNumSalle(string $numSalle):void{
        $this->numSalle = $numSalle;
    }
    function setEquipement(Equipement $equipement):void{
        $this->equipement = $equipement;
    }
    function setQte(int $qte):void{
        $this->qte = $qte;
    }
}
?>
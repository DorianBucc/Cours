import { Description } from "./Description.ts";

export class Role {
  private _description!: Description;

  public constructor(description: Description) {
    this.description = description;
  }

  public set description(description: Description) {
    this._description = description;
  }

  public get description(): string {
    return this._description;
  }

  public toString(): string {
    return this._description.toString();
  }
}

import { Departement } from "./Departement.ts";

export class Enseignant {

    private _nom!: string;
    private _prenom!: string;
    private _volumesHoraire: Map<Departement, number>;

    public constructor(nom: string, prenom: string) {
        this.nom = nom;
        this.prenom = prenom;
        this._volumesHoraire = new Map<Departement, number>();
    }

    public ajouteVolumeHoraire(departement: Departement, volumeHoraire: number): void {
        const actuel = this._volumesHoraire.get(departement);

        if (actuel===undefined) {
            this._volumesHoraire.set(departement, volumeHoraire);
        } else {
            this._volumesHoraire.set(departement, actuel  + volumeHoraire);
        }
    }

    public retireVolumeHoraire(departement: Departement, volumeHoraire: number): void {
        const actuel = this._volumesHoraire.get(departement);
        if (actuel===undefined) {
            throw new Error("Aucune heure n'est faite dans ce département !");
        }
        else if (actuel===volumeHoraire) {
            this._volumesHoraire.delete(departement);
        } else if (actuel < volumeHoraire) {
            throw new Error("Le volume horaire à retirer est supérieur au volume horaire actuel !");
        } else {
            this._volumesHoraire.set(departement, actuel - volumeHoraire);
        }
    }

    public get volumeHoraire(): Map<Departement, number> {
        return this._volumesHoraire;
    }

    public volumeHoraireToString(): string {
        let res = "";
        for (const [departement, volumeHoraire] of this._volumesHoraire) {
            res += departement.toString() + " : " + volumeHoraire + "\n";
        }
        return res;
    }

    public set nom(nom: string) {
        nom = nom.trim().toUpperCase();
        if (nom.length < 2) {
            throw new Error("Le nom de l'enseignant doit contenir au moins 2 caractères");
        }
        this._nom = nom;
    }
    
    public get nom(): string {
        return this._nom;
    }
    
    public set prenom(prenom: string) {
        prenom = prenom.trim();
        if (prenom.length < 2) {
            throw new Error("Le prénom de l'enseignant doit contenir au moins 2 caractères");
        }
        this._prenom = prenom;
    }
    
    public get prenom(): string {
        return this._prenom;
    }

    public toString(): string {
        return this._nom + " " + this._prenom;
    }
}
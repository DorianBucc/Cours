import { Epreuve } from "./Epreuve.ts";
import { TypeEpreuve } from "./TypeEpreuve.ts";

export class Saut extends Epreuve {
  constructor(nom: string) {
    super(nom, "mètres", TypeEpreuve.Saut);
  }
}

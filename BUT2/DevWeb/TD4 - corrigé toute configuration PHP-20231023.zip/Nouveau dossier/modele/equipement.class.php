<?php
class Equipement {
    
    private $id;
    private $libelle;
    private $commentaire;

    // constructeur    
    function __construct(string $id='', string $libelle='', string $commentaire='') {
        $this->id = $id;
        $this->libelle = $libelle;
        $this->commentaire = $commentaire;
    }

    // getters
    function getId():string{
        return $this->id;
    }
    function getLibelle():string{
        return $this->libelle;
    }
    function getCommentaire():string | null{
        return $this->commentaire;
    }

    // setters    
    function setId(string $id):void{
        $this->id = $id;
    }
    function setLibelle(string $libelle):void{
        $this->libelle = $libelle;
    }
    function setCommentaire(string|null $commentaire):void{
        $this->commentaire = $commentaire;
    }


}


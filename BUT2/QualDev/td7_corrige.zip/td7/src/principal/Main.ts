import { BanditManchot } from "../modele/BanditManchot.ts";
import { BanditManchotType1 } from "../modele/BanditManchotType1.ts";
import { BanditManchotType2 } from "../modele/BanditManchotType2.ts";
import { litChaine, litEntier } from "../utils/Saisie.ts";
import { litReel } from "../utils/Saisie.ts";

function main(): void {
  let rep: string;

  let type: number;
  do {
    type = litEntier("Type de bandit manchot ? (1 ou 2) ? ");
  } while (type !== 1 && type !== 2);

  let bm: BanditManchot;
  if (type === 1) {
    bm = new BanditManchotType1();
  } else {
    bm = new BanditManchotType2();
  }

  do {
    let res: number[];
    let recommencer: boolean;
    do {
      recommencer = false;
      try {
        console.log("Mise possibles : " + bm.misesPossibles);

        const mise = litReel("Mise ? ");
        res = bm.getResultatLancement(mise);
      } catch (e) {
        recommencer = true;
        console.log(e.message);
      }
    } while (recommencer);
    const tirage = res!.slice(0, res!.length - 1);
    const gain = res![res!.length - 1];
    console.log(tirage);
    if (gain > 0) {
      console.log("Gagné " + gain);
    } else {
      console.log("Perdu");
    }
    rep = litChaine("Continuer ? ").toUpperCase();
  } while (rep === "OUI" || rep === "O");
}

main();

export default class ChainePerso {
  private _chaine: string;

  constructor() {
    this._chaine = "";
  }

  saisieClavier(msg = ""): void {
    do {
      this._chaine = prompt(
        msg === "" ? "Veuillez saisir une chaîne quelconque : " : msg,
      )!;
    } while (this._chaine === null);
  }

  get chaine(): string {
    return this._chaine;
  }

  generationAleatoireVoyelles(taille: number): void {
    const voyelles = ["a", "e", "i", "o", "u"];
    const longueur = voyelles.length;
    // Ajout des majuscules
    for (let v = 0; v < longueur; v++) {
      voyelles.push(voyelles[v].toUpperCase());
    }

    this._chaine = "";

    for (let i = 0; i < taille; i++) {
      const indice = Math.floor(voyelles.length * Math.random());
      this._chaine += voyelles[indice];
    }
  }

  crypte(): void {
    const lettres = ["A", "B", "E", "G", "I", "O", "S", "Z"];
    const cryptees = ["4", "8", "3", "6", "1", "0", "5", "2"];

    let chCryptee = "";
    for (let c = 0; c < this._chaine.length; c++) {
      // recherche de la cième lettre de la chaîne dans le tableau
      // des lettres à crypter
      // si on ne trouve pas (idx=-1), on concatène la lettre
      // sinon on concatène sa version cryptée
      const idx = lettres.indexOf(this.chaine[c]);
      if (idx === -1) {
        chCryptee += this._chaine[c];
      } else {
        chCryptee += cryptees[idx];
      }
    }

    this._chaine = chCryptee;
  }

  generationAleatoire(taille: number): void {
    let resultat: string;
    //let compteur = 0;

    do {
      resultat = "";
      for (let i = 0; i < taille; i++) {
        let car = String.fromCharCode(65 + (123 - 65) * Math.random());
        resultat += car;
      }
      //compteur++;
      //console.log('Tentative ' + compteur + ' : ' + resultat);
    } while (resultat !== resultat.toUpperCase());
    //console.log('Nb itérations : ' + compteur);

    this._chaine = resultat;
  }

  toString(): string {
    return this._chaine;
  }

  affiche(): void {
    console.log(this.toString());
  }
}

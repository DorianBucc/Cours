export class MonSingleton {

    private static _instance : MonSingleton;

    private _texte : string;

    private constructor(texte : string) {
        this._texte = texte;
    }

    public static getInstance(texte = "") : MonSingleton {

        if (MonSingleton._instance === undefined) {
            MonSingleton._instance = new MonSingleton(texte);
        } else {
            MonSingleton._instance._texte = texte;
        }
        return MonSingleton._instance;
    }

    public set texte(texte : string) {
        this._texte = texte;
    }

    public get texte() : string {
        return this._texte;
    }

    public toString() : string {
        return "Texte : " + this._texte;
    }
}
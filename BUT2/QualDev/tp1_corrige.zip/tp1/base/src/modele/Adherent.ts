import { Personne } from "./Personne.ts";

export class Adherent extends Personne {
  private _numero!: string;

  public constructor(numero: string, nom: string, prenom: string) {
    super(nom, prenom);
    this.numero = numero;
  }

  public set numero(numero: string) {
    if (numero.match(/^([0-9]+)$/)) {
      this._numero = numero;
    } else {
      throw new Error("Le numéro d'adhérent doit être numérique.");
    }
  }

  public get numero(): string {
    return this._numero;
  }

  public toString(): string {
    return this._numero + " " + super.toString();
  }
}

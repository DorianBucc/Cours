export class Enseignant {
    private _code!: number;
    private _nom!: string;
    private _prenom!: string;

    constructor(code: number, nom: string, prenom: string) {
        this.code = code;
        this.nom = nom;
        this.prenom = prenom;
    }

    get nom(): string {
        return this._nom;
    }

    set nom(value: string) {
        if (value.length > 1) { 
            this._nom = value.trim().toUpperCase();
        } else {
            throw new Error("Le nom doit contenir au moins 2 caractères");
        }
    }

    get prenom(): string {
        return this._prenom;
    }

    set prenom(value: string) {
        if (value.length > 1) {
            this._prenom = value.charAt(0).toUpperCase() + value.substring(1).toLowerCase();
        } else {
           throw new Error("Le prénom doit contenir au moins 2 caractères");
        } 
    }

    get code(): number {
        return this._code;
    }

    set code(value: number) {
        this._code = value;
    }

    toString(): string {
        return `${this._prenom} ${this._nom} (${this._code})`;
    }
}
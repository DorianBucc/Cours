import { litChaine, litEntier } from "../utils/Saisie.ts";
import { Sportif } from "../modele/Sportif.ts";
import { Compte } from "../modele/tiers/Compte.ts";
import { ObjetConnecte } from "../modele/tiers/ObjetConnecte.ts";
import { Activite } from "../modele/activites/Activite.ts";
import { FournisseurDonnees } from "../modele/tiers/FournisseurDonnees.ts";
import { Cyclisme } from "../modele/activites/Cyclisme.ts";
import { CourseAPied } from "../modele/activites/CourseAPied.ts";
import { Musculation } from "../modele/activites/Musculation.ts";


function creeMembres() : Array<Sportif> {
    const membre1 = new Sportif(1, "Jean", "Dupont", new Date(1980, 1, 1), "M", 180, 70);
    const membre2 = new Sportif(2, "Marie", "Durand", new Date(1985, 2, 2), "F", 170, 50);
    const membre3 = new Sportif(3, "Pierre", "Martin", new Date(1990, 3, 3), "M", 190, 90);

    const membres = [membre1, membre2, membre3];

    return membres;
}

function ajouteComptes(membres : Array<Sportif>) : void {
    
    const objJD = new ObjetConnecte(124710, "Montre");
    const objMD = new ObjetConnecte(124711, "Tacx");
    const objPM = new ObjetConnecte(325710, "Montre");
    membres[0].ajouterFournisseurDonnees(objJD);
    membres[1].ajouterFournisseurDonnees(objMD);
    membres[2].ajouterFournisseurDonnees(objPM);
    
    const cptJD = new Compte(124712, "Polar");
    const cptMD = new Compte(124713, "Garmin");    
    membres[0].ajouterFournisseurDonnees(cptJD);
    membres[1].ajouterFournisseurDonnees(cptMD);
    
    const strJD = new Compte(124714, "Strava");
    objJD.ajouterCompteLie(strJD);
    cptJD.ajouterCompteLie(strJD);
    
    const strMD = new Compte(124715, "Strava");
    objMD.ajouterCompteLie(strMD);
    cptMD.ajouterCompteLie(strMD);

    const strPM = new Compte(124716, "Strava");
    objPM.ajouterCompteLie(strPM);

    const decJD = new Compte(124717, "Decathlon");
    objJD.ajouterCompteLie(decJD);
    cptJD.ajouterCompteLie(decJD);
}

function afficheDonnees(membres : Array<Sportif>) : void {

    console.log("Liste des membres du club :");
    for (const membre of membres) {
        console.log(membre.toString());
        console.log("Liste des comptes du membre :");
        for (const compte of membre.listeComptes) {
            console.log("\t" + compte.toString());

            console.log("\tListe des comptes connectés :");
            for (const cpt of compte.listeComptesLies) {
                console.log("\t\t" + cpt.toString());
            }
        }
    }
}


function saisiePartieActivite() : [Date, number, number] {

    const dateActivite = new Date(Date.now());
    const duree = litEntier("Durée de l'activité : ");
    const bpmMoyen = litEntier("BPM moyen : ");

    return [dateActivite, duree, bpmMoyen];
}

function saisieCyclisme(noActivite : number, fournisseur : FournisseurDonnees) : Activite {

    const [dateActivite, duree, bpmMoyen] = saisiePartieActivite();
    const distance = litEntier("Distance : ");
    const denivele = litEntier("Dénivelé : ");
    const vitesse = litEntier("Vitesse : ");

    return new Cyclisme(noActivite, dateActivite, duree, bpmMoyen, distance, denivele, vitesse, fournisseur);
}

function saisieCourseAPied(noActivite : number, fournisseur : FournisseurDonnees) : Activite {

    const [dateActivite, duree, bpmMoyen] = saisiePartieActivite();
    const distance = litEntier("Distance : ");
    const cadence = litEntier("Cadence : ");

    return new CourseAPied(noActivite, dateActivite, duree, bpmMoyen, distance, cadence, fournisseur);
}

function saisieMusculation(noActivite : number, fournisseur : FournisseurDonnees) : Activite {

    const [dateActivite, duree, bpmMoyen] = saisiePartieActivite();
    const titre = litChaine("Titre : ");
    const membre = litChaine("Membre : ");

    return new Musculation(noActivite, dateActivite, duree, bpmMoyen, titre, membre, fournisseur);
}

function interactions(membres : Array<Sportif>) : void {

    let noActivite = 5436;

    let noMembre : number;
    do {
        do {            
            noMembre = litEntier("Quel membre ? (0 pour quitter) : ");
        } while (noMembre < 0 || noMembre > membres.length);
        if (noMembre===0) {
            break;
        }    

        console.log("Liste des comptes du membre :");
        let cpt=0;
        for (const compte of membres[noMembre].listeComptes) {
            console.log(`\t${cpt} ${compte.toString()}`);
            cpt++;
        }

        let noCpt:number;
        do {
            noCpt = litEntier("Quel compte ? ");
        } while (noCpt < 0 || noCpt >= cpt);

        console.log("Activité ?");
    } while (noMembre !== 0);
}


const membres = creeMembres();
ajouteComptes(membres);
afficheDonnees(membres);

interactions(membres);



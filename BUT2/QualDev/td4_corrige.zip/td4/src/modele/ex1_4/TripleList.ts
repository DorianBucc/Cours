import { Triple } from "./Triple.ts";

export class TripleList<T, U, V> {

    private list: Array<Triple<T, U, V>>;
    
    constructor() {
        this.list = new Array<Triple<T, U, V>>();
    }

    public add(triple: Triple<T, U, V>): void {
        this.list.push(triple);
    }
    public get(index: number): Triple<T, U, V> {
        if (index < 0 || index >= this.list.length) {
            throw new Error("Erreur : index hors limite !");
        }
        return this.list[index];
    }
    public size(): number {
        return this.list.length;
    }
    public toString(): string {
        let result = "";
        for (let i = 0; i < this.list.length; i++) {
            result += this.list[i].toString() + "\n";
        }
        return result;
    }

    public forEach(callback: (element: Triple<T, U, V>, idx : number, 
        array:Array<Triple<T,U,V>>) => void): void {
        this.list.forEach(callback);
    }

    public reduce(callback: (accumulator: Triple<T, U, V>, currentValue: Triple<T, U, V>, currentIndex : number, array:Array<Triple<T,U,V>>) => Triple<T, U, V>, initialValue: Triple<T, U, V>): Triple<T, U, V> {
        return this.list.reduce(callback, initialValue);
    }
}
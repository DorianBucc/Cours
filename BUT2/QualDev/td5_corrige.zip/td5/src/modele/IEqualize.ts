export interface IEqualize {
    equals(obj: object): boolean;
}
const tab = [1, 5, 8, 25];


tab.forEach(console.log);

console.log(tab.every(elt => elt>0)); // true (tous > 0)
console.log(tab.some(elt => elt>70)); // false (aucun > 70)
console.log("ICI");

console.log(tab.some(elt => {
    if (elt%2===0) {
        return elt > 30;
    } else {
        return elt > 24;
    }
}));

console.log(tab.find(elt => elt>5)); // 8 (le 1er supérieur à 5)
console.log(tab.findLast(elt => elt>5)); // 25 (le dernier supérieur à 5)
console.log(tab.find(elt => elt>75)); // undefined

console.log(tab.findIndex(elt => elt>5)); // 2 (l'indice du 1er supérieur à 5)
console.log(tab.findLastIndex(elt => elt>5)); // 3 (l'indice du dernier supérieur à 5)

console.log(tab.filter(elt => elt%2>2)); // [8]   
console.log(tab.map(elt => elt*2)); // [2, 10, 16, 50]
console.log(tab);

console.log(tab.map(elt => {
    if (elt%2===0) {
        return elt*2;
    } else {
        return elt;
    }
})); // [1, 5, 16, 25]

console.log(tab.sort((a,b) => b-a)); // [25, 8, 5, 1]
console.log(tab);

tab.reduce((cumul, elt) => cumul+elt, 0); // 39
tab.reduceRight((cumul, elt) => cumul+elt, 0); // 39


console.log(tab.flatMap(elt => [elt, elt*2, elt*3])); // [1, 2, 3, 5, 10, 15, 8, 16, 24, 25, 50, 75]

